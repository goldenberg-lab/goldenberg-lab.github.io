function res =  get_cancertype_predictions(train_betas, y_train, test_betas, y_test)

fit = glmnet(train_betas',y_train,'multinomial');
predmat = glmnetPredict(fit, 'response',test_betas');  
TPrate = zeros(1,size(predmat,3));
TPconf = zeros(size(predmat,1),size(predmat,3));
Pred = TPconf;
for i = 1:size(predmat,3)
	[TPconf(:,i) Pred(:,i)] = max(predmat(:,:,i),[],2);
	TPrate(i) = nnz((y_test-Pred(:,i))==0)/length(y_test);      
end;
res.fit = fit;
res.predmat = predmat;
res.TPrate = TPrate;
res.TPconf = TPconf;
res.Pred = Pred;
res.ytest = y_test;

acc90ind = find(TPrate>.9,1)
acc95ind = find(TPrate>.95,1)
acc99ind = find(TPrate>.99,1)
res.acc90ind = acc90ind;
res.acc95ind = acc95ind;
res.acc99ind = acc99ind;
for i = 1:length(unique(y_train)) temp{i} = find(fit.beta{i}(:,acc90ind));
end;
res.mirnas90 = cell2mat(temp');
for i = 1:length(unique(y_train)) temp{i} = find(fit.beta{i}(:,acc95ind));
end;
res.mirnas95 = cell2mat(temp');
for i = 1:length(unique(y_train))  temp{i} = find(fit.beta{i}(:,acc99ind));
end;
res.mirnas99 = cell2mat(temp');
res.df95 = fit.df(acc95ind);
res.df99 = fit.df(acc99ind);
res.df90 = fit.df(acc90ind);