%load directors
if (0)
for i = 1:4
 i
 fprintf('loading net...\n');
 net = load_mirna_net; 
 fprintf('loading data...\n');
 d1 = load_denoised_dir_from_mat(i);
 fprintf('analyzing...\n');
 res{i} = run_mirna_one_ds(d1,net);
end;
end;

%p = genpath('~/cannet/code/matlab/');
%addpath(p);

%datasets= {'GSE10072'; 'GSE13597'; 'GSE15852'; 'GSE3167'; 'GSE12907'; 'GSE15641'; 'GSE21122'; 'GSE6008'};
datasets = {'GSE10810'; 'GSE10927'; 'GSE11024'; 'GSE11151'; 'GSE12368'; 'GSE13601'; 'GSE13911'; ...
	'GSE14001'; 'GSE15471'; 'GSE16515';'GSE19826'; 'GSE23878'; 'GSE6631'; 'GSE7904'; 'GSE8607';...
'GSE8671'; 'GSE9348'; 'GSE9844'};

alldatasets = {'GSE10072'; 'GSE13597'; 'GSE15852'; 'GSE3167'; 'GSE12907'; 'GSE15641'; 'GSE21122'; 'GSE6008';...
'GSE10810'; 'GSE10927'; 'GSE11024'; 'GSE11151'; 'GSE12368'; 'GSE13601'; 'GSE13911'; ...
        'GSE14001'; 'GSE15471'; 'GSE16515';'GSE19826'; 'GSE23878'; 'GSE6631'; 'GSE7904'; 'GSE8607';...
'GSE8671'; 'GSE9348'; 'GSE9844'};

datanames = {'Breast';'Adrenocortical';'Renal';'Renal mixed';'Adrenocortical';'Tongue SSC';...
'Gastric';'Ovarian';'Pancreatic';'Pancreatic';'Gastric';'Colorectal';'HeadNeck SSC';...
'Breast';'Testicular';'Colorectal Ad';'Colorectal';'Tongue SSC'};

net = load_mirna_net;

currdir = 'data/';
ind = 1;
for i = 1:length(datasets)
i
fprintf('loading tumordata data\n');
  tumname = [currdir datasets{i} '.log2profbeta.txt'];
  [tumorgenes tumornames tumdata] = readmatwlabels(tumname,1);
  normname = [currdir datasets{i} '.normal.txt'];
fprintf('loading normal data\n');
  [normgenes normnames normdata] = readmatwlabels(normname);
  [genes IT IN] = intersect(str2double(tumorgenes),str2double(normgenes));
  if (length(genes) > 0)
  d1.tumornames = tumornames;
  d1.normalnames = normnames;
  d1.tumordata = tumdata(IT,:);
  d1.normaldata = normdata(IN,:);
  d1.genes = str2double(tumorgenes(IT));
  fprintf('analyzing...\n');
   moreres{ind} = run_mirna_one_ds(d1,net);
   ind = ind+1;
  end;
end;
