addpath(genpath('~/cannet/code/matlab/'))

alldatasets = {'Dir1';'Dir2';'Dir3';'Dir4';'GSE10072';  'GSE15852'; 'GSE3167'; 'GSE12907';  'GSE21122'; ...
 'GSE10927'; 'GSE11024'; 'GSE11151'; 'GSE12368'; 'GSE13911'; ...
        'GSE15471'; 'GSE16515';'GSE19826'; 'GSE23878';...
'GSE8671'; 'GSE9348'; 'GSE9844'};

allnames = {   
'Adeno Dir1';
    'Adeno Dir2';
    'Adeno Dir3';
    'Adeno Dir4';
    'Adenocarcinoma';
    'Breast';
    'Bladder';
    'JPA';
    'STC';
    'Adrenocortical';
    'Renal';
    'Renal Mixed';
    'Adrenocortical';
    'Gastric';
    'Pancreatic';
    'Pancreatic';
    'Gastric';
    'Colorectal';
    'Colorectal Ad';
    'Colorectal';
    'Tongue SSC'};

currdir = '/home/amit/level2/';

alldata = [];

net = load_mirna_net;

for i = 1:4
 d1{i} = load(['~/cannet/director/dir' num2str(i) 'profiles.denoised.mat']);
 d1{i}.tumordata = d1{i}.data{92};
 d1{i}.data = normalize_expr_data(d1{i}.tumordata,d1{i}.normaldata,1);
 d1{i}.name = alldatasets{i};
 d1{i}.type = allnames{i};
end;

for i = 5:length(alldatasets)
i
fprintf('loading tumordata data\n');
  tumname = [currdir alldatasets{i} '.log2profbeta.txt'];
  [tumorgenes tumornames tumdata] = readmatwlabels(tumname,1);
  normname = [currdir alldatasets{i} '.normal.txt'];
fprintf('loading normal data\n');
  [normgenes normnames normdata] = readmatwlabels(normname);
  [genes IT IN] = intersect(str2double(tumorgenes),str2double(normgenes));
  if (length(genes) > 0)
  d1{i}.tumornames = tumornames;
  d1{i}.normalnames = normnames;
  d1{i}.tumordata = tumdata(IT,:);
  d1{i}.normaldata = normdata(IN,:);
  d1{i}.genes = str2double(tumorgenes(IT));
  d1{i}.name = alldatasets{i};
  d1{i}.type = allnames{i}
  d1{i}.data = real(normalize_expr_data(d1{i}.tumordata,d1{i}.normaldata));
  end;
end;

genes_inds = zeros(length(net.genes),length(d1));
ind_ln = [];
for i = 1:length(d1)
  [genes IN ID] = intersect(net.genes,d1{i}.genes);
  genes_inds(IN,i) = 1;
  if length(IN) > 5000 
   ind_ln = [ind_ln i];
  end;
end;

convmat = [1 1 1 1 1 2 3 4 5 6 7 7 6 8 9 9 8 10 10 10 11];

common_gene_inds = find(sum(genes_inds(:,ind_ln),2) == length(ind_ln));
alldata = [];
alldata_std = [];
all_ys = [];
all_ys11 = [];
ma = [];
ma_std = [];
for i = 1:length(ind_ln)
  [genes ID IN] = intersect(d1{ind_ln(i)}.genes,net.genes(common_gene_inds));
  currdata = real(d1{ind_ln(i)}.data(ID,:));
  currdata_std = remove_mean(currdata);
  alldata = [alldata currdata];
  alldata_std = [alldata_std currdata_std];
  all_ys = [all_ys; i*ones(size(currdata,2),1)];
%  all_ys11 = [all_ys11; convmat(ind_ln(i))*ones(size(currdata,2),1)];
  ma = [ma mean(currdata,2)];
  ma_std = [ma_std mean(currdata_std,2)];
end;

cc_ma_std = corrcoef(ma_std)
save ../alldata_for_mirna_selection.mat alldata genes net
save ../alldata_std_for_mirna_selection.mat alldata_std genes net