function net = load_mirna_net()

  load('data/mirna_network_notnorm.mat');
net.genes = newD.rowlabels;
net.mirnas = newD.collabels;
net.data = newD.data;
