%res = run_mirna_one_ds('director1.mat');
function res = run_mirna_one_ds(d1,net)

[genes IN ID] = intersect(net.genes,d1.genes);

fprintf('there are %d genes\n',length(genes));
if (length(genes) > 0)
exprN = normalize_expr_data(d1.tumordata,d1.normaldata,1);
expr.data = exprN(ID,:);
expr.tumor = d1.tumornames;
expr.rowlabels = d1.genes(ID);
network = net.data(IN,:);

res.netsize = size(network);
res.betas = zeros(length(net.mirnas),size(expr.data,2));
for ii = 1:size(expr.data,2);
    CVerr = cvglmnet(full(network),full(expr.data(:,ii)),10,[],'response','gaussian',glmnetSet,0);%glmnet(full(network),full(expr.data(:,ii)));
    ind = find(CVerr.stderr == min(CVerr.stderr));
    res.betas(:,ii) = CVerr.glmnet_object.beta(:,ind);
    res.dev(ii) = CVerr.glmnet_object.dev(ind);
    res.df(ii) = CVerr.glmnet_object.df(ind);
end
    res.tumornames = d1.tumornames;
    res.mirnas = net.mirnas;

end;
