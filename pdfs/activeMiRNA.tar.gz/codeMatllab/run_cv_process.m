 addpath(genpath('~/cannet/code/matlab/'))
%withold final test
final_test_X = [];
final_test_y = [];
all_train_betas = [];
all_train_ys = [];
all24inds = [];
all13inds = [];
for i = 1:24
  numpatients = size(totres24{i}.betas,2);
%  if (numpatients > 50)
    temp = randperm(numpatients);
    num = floor(numpatients*.1);
    final_inds = temp(1:num); 
    train_inds = setdiff(1:numpatients,final_inds);
    final_test_X = [final_test_X totres24{i}.betas(:,final_inds)];
    final_test_y = [final_test_y; classconv(i,2)*ones(num,1)]; 
    totres24{i}.train_betas = totres24{i}.betas(:,train_inds); 
    totres24{i}.train_y = classconv(i,2)*ones(length(train_inds),1);
    totres24{i}.final_inds = final_inds;
    all_train_betas = [all_train_betas totres24{i}.betas(:,train_inds)];
    all_train_ys = [all_train_ys; classconv(i,2)*ones(length(train_inds),1)];
    all24inds = [all24inds; i*ones(length(train_inds),1)];
    all13inds = [all13inds; classconv(i,2)*ones(length(train_inds),1)];
%   end;
end;

%for dsn = 1:13
%  fprintf('predicting dataset %d\n',dsn);
%  dsn_inds = randperm(size(all_train_betas,2));%find(all24inds == i);
%  holdout_rate = floor(length(dsn_inds)/10);
%  holdout_inds = dsn_inds((dsn-1)*holdout_rate+1:dsn*holdout_rate);
  use_inds = 1:size(all_train_betas,2);%randperm(size(all_train_betas,2));%setdiff(dsn_inds,holdout_inds);

  % 10 fold cross-validation
  allinds = randperm(length(use_inds));
  allinds = use_inds(allinds);
  numpatients = length(allinds);
  x = floor(numpatients/10); 
  for fold = 1:10
     fprintf('Iteration %d\n',fold);
     testinds = allinds((fold-1)*x+1:fold*x);
     traininds = setdiff(allinds,testinds); 
     res{fold} = get_cancertype_predictions(all_train_betas(:,traininds),all_train_ys(traininds),...
all_train_betas(:,testinds),all_train_ys(testinds));
  end 

   allmirnas95 = zeros(153,10);
   for i = 1:10
      allmirnas95(res{i}.mirnas95,i) = 1;
   end;
   model95{dsn} = nnz(sum(allmirnas95,2)>5);
   allmirnas99 = zeros(153,10);
   for i = 1:10
     allmirnas99(res{i}.mirnas99,i) = 1;
   end;
   model99{dsn} = nnz(sum(allmirnas99,2)>5);
   fit = glmnet(train_betas',y_train,'multinomial',);
   
B = mnrfit(all_train_betas(find(sum(allmirnas99,2)>5),:)',all_train_ys,'model','ordinal');
yhat = mnrval(B,final_test_X(find(sum(allmirnas99,2)>5),:)','model','ordinal');

%catnames = {'Ade';'STC';'Adr';'Gas';'Pan';'Ren*';'Ton*';'Bla';'JPA';'Ton';'Hea';'Tes';'Bre'};
catnames = {'Ade';'Bre';'Bla';'JPA';'STC';'Adr';'Ren';'Gas';'Pan';'Col';'Ton'};
auc = zeros(1,length(catnames));
aupr = auc;
for i = 1:length(catnames)
   y_tru = final_test_y;
   y_tru(find(y_tru ~= i)) = 0;
   [tpr{i} fpr{i} pr{i} re{i} class0err{i} class1err{i} fstat{i} auc(i) aupr(i)] = roc_pr(y_tru,...
holdout_expr_predmat(:,i),catnames(i));
   fprintf('%4s %4.2f %4.2f\n',catnames{i},auc(i),aupr(i));
end

totbetas21 = [];
for i = 1:21

totbetas21 = [totbetas21 totres21{i}.betas];
end;
 
  
CVerr=cvglmnet(all_train_betas',all_train_ys,10,[],'class','multinomial',glmnetSet,0);
holdout_predmat = glmnetPredict(CVerr.glmnet_object, 'response',final_test_X', CVerr.lambda_min);
y_tru = final_test_y;
for i = 1:11
[tpr{i} fpr{i} pr{i} re{i} class0err{i} class1err{i} fstat{i} auc(i) aupr(i)] = roc_pr(y_tru,...
holdout_predmat(:,i),catnames{i});
end;
holdout_expr_predmat = glmnetPredict(CVerr_expr.glmnet_object, 'response',final_test_X', CVerr_expr.lambda_min);

for i = 1:length(catnames)
  y_tru = final_test_y;
  y_tru(find(y_tru ~= i)) = 0;
  [tpr{i} fpr{i} pr{i} re{i} class0err{i} class1err{i} fstat{i} auc(i) aupr(i)] = roc_pr(y_tru,...
holdout_predmat(:,i),catnames(i));
  fprintf('%4s %4.2f %4.2f\n',catnames{i},auc(i),aupr(i));
end

lind = find(CVerr.glmnet_object.lambdas == CVerr.lambda_min);
mirna_inds= [];
for i = 1:11
 mirna_inds = [mirna_inds; find(CVerr.glmnet_object.beta{i}(:,lind))];
end;