fid = fopen('microcosm_mirna_to_entrezid.txt','r');
net_cell = textscan(fid,'%s %d\n','delimiter',' ');
net_cell{1} = net_cell{1}(1:end-1);
fclose(fid);
[M Imi Jmi] = unique(net_cell{1});
[G Ig Jg] = unique(net_cell{2});
net.mirnas = unique(net_cell{1});
net.genes = unique(net_cell{2});
net.data = sparse(Jmi,Jg,ones(length(Jg),1),length(net.mirnas),length(net.genes));
