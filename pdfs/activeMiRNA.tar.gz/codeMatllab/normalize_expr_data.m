%Normalizing data according to SAM (tibshirani et al, 2002)
%function expr = normalize_expr_data(tumor,normal)
function expr = normalize_expr_data(tumor,normal,logtumflag,meanflag)

nargin
if nargin < 3
 logtumflag = 0;
end
if nargin < 4
 meanflag = 1;
else
 meanflag = 0;
end;

normal = log2(normal);
if (~logtumflag)
['taking the log']
  tumor = log2(tumor);
end;
mean_norm = mean(normal,2);
if meanflag
  mean_tumor = mean(tumor,2);
end;

stds = std(normal,[],2);
numtumor = size(tumor,2);
numnorm = size(normal,2);
a = (1/numtumor+1/numnorm)/(numtumor+numnorm-2);
s_i = sum((normal-repmat(mean_norm,1,numnorm)).^2,2)+sum((tumor-repmat(mean_tumor,1,numtumor)).^2,2);
s_i = sqrt(a*s_i);
if (0)
d_i = (mean_tumor-mean_norm)./s_i;
        x = 0:.1:100;
        for i = 1:length(x)
        ffxi = (mean_female-mean_norm)./(s_i_f+x(i));
                fmxi = (mean_male-mean_norm)./(s_i_m+x(i));
                std_ffxi(i) = std(ffxi);
                mean_ffxi(i) = mean(ffxi);
                std_fmxi(i) = std(fmxi);
                mean_fmxi(i) = mean(fmxi);
                diffxi(i) = abs(std_ffxi/mean_ffxi-std_fmxi/mean_fmxi);
        end;
        find(diffxi == min(diffxi))
end;
expr = (tumor-repmat(mean_norm,1,numtumor))./repmat(s_i+1,1,numtumor);
