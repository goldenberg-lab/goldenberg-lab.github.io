fid = fopen('miR_Family_Info.txt','r');                      
FamilyInfo = textscan(fid,'%s%s%s%s%s%s%s','Delimiter','\t');
fclose(fid)

mirna_ind = lookup(mirna_tumorgenes,FamilyInfo{4});
nnanind = find(~isnan(mirna_ind));
found_mirnas = mirna_ind(nnanind);
relevant_families = FamilyInfo{1}(found_mirnas);    
famind = lookup(FamilyInfo{1}(found_mirnas),net.mirnas);
nnfamind = find(~isnan(famind));
found_fams = found_mirnas(nnfamind);
alphas = mirna_sel(famind(nnfamind),mrna_ind(1:10));
[patients mirna_ind mrna_ind] = intersect(mirna_tumornames,tumornames);
true_mirna_ed = mirna_data(nnanind,mirna_ind(1:10));

nnz_mirna_sel = find(sum(mirna_sel~=0,2)>2);
selected_mirnas = net.mirnas(nnz_mirna_sel)

selected_mirna_inFam_ind = lookup(selected_mirnas,FamilyInfo{1});
for i = 1:length(selected_mirna_inFam_ind)
  currIndFam = find(strcmp(FamilyInfo{1},FamilyInfo{1}(selected_mirna_inFam_ind(i))));   
  x = lookup(mirna_tumorgenes,FamilyInfo{4}(currIndFam));
  corresp_obs_data{i} = obs_mirna_de_levels(~isnan(x),:);
end
for i = 1:length(corresp_obs_data)
  num_memb = size(corresp_obs_data{i},1);
  if (num_memb > 0)
    currsum = sum(sign(corresp_obs_data{i}),1);
    disagreement = find(abs(currsum) < num_memb);
    currsum(disagreement) = 0;
    currsum = currsum./num_memb;
    prodofsigns = sum(currsum.*sign(mirna_sel_corresp_to_obs(i,:)),1);
    TP = nnz(prodofsigns == -1);
    FP = nnz(prodofsigns == 1);
    fprintf('%2d %3d %3d\n',i, TP, FP);
  end
end 

obs_mirnas = FamilyInfo{4}(found_mirnas(nnind_found_mirna_into_meas_fam))
ind_into_sel_mirna = nnz_mirna_sel(nnind_found_mirna_into_meas_fam);
ind_into_obs_mirna = find(~isnan(lookup(mirna_tumorgenes,obs_mirnas)));
lookup(net.mirnas(ind_into_sel_mirna),mirna_tumorgenes(ind_into_obs_mirna))
 mirna_sel_corresp_to_obs = mirna_sel(nnz_mirna_sel,mrna_ind);
found_fams_found_mirnas(nnind_found_mirna_into_meas_fam)
obs_mirna_de_levels = mirna_data(find(~isnan(lookup(mirna_tumorgenes,obs_mirnas))),mi_tumnames);

%by hand
for patient = 1:10
nz_mirnas = find(mirna_sel(:,mrna_ind(patient)));
matched_mirnas = mirna_data(nnanind,:);
[val ranks] = sort(abs(matched_mirnas(:,mirna_ind(patient))),'descend');
for i= 1:length(nz_mirnas)
  x = find(famind == nz_mirnas(i));
%  max(abs(matched_mirnas(x,1)))
  max_rank = max(lookup(x,ranks));
  fprintf('patient=%d family %d alpha = %f max_rank = %d\n',patient,nz_mirnas(i),mirna_sel(nz_mirnas(i),...
mrna_ind(patient)),max_rank);
end
end

mirna_normname = 'mskcc.miRNA.normal.txt'; %fix
mirna_tumname = '/home/amit/MSKCC/mskcc.miRNA.log2profbeta.txt';
[mirna_tumorgenes mirna_tumornames mirna_tumdata] = readmatwlabels(mirna_tumname,1);
[mirna_normgenes mirna_normnames mirna_normdata] = readmatwlabels(mirna_normname);
mirna_data = real(normalize_expr_data(mirna_tumdata,mirna_normdata)); 
