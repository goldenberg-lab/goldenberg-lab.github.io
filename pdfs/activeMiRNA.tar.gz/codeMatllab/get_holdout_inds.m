%function get_holdout_inds(alldata,all_ys,all_10ys)

final_test_X = [];
final_test_y = [];
train_betas = [];
train_ys = [];
all_train_data = [];
all_train_y11s = [];
all_final_inds = [];
all_train_inds = [];
for i = 1:length(unique(all_ys))
   currinds = find(all_ys11 == i);
   numpatients = size(alldata(:,currinds),2);
    temp = randperm(numpatients);
    num = floor(numpatients*.2);
    final_inds = currinds(temp(1:num));
    all_final_inds = [all_final_inds; final_inds];
    train_inds = setdiff(currinds,final_inds);
    all_train_inds = [all_train_inds; train_inds];
    final_test_X = [final_test_X alldata(:,final_inds)];
    final_test_y = [final_test_y; all_ys11(final_inds)];
    all_train_data = [all_train_data alldata(:,train_inds)];
    all_train_y11s = [all_train_y11s; all_ys11(train_inds)];
end;