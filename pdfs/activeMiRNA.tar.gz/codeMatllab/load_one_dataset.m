i = 1
currdir = '';
alldatasets = {'mskcc'};
fprintf('loading tumordata data\n');
  tumname = [currdir alldatasets{i} '.log2profbeta.txt'];
  [tumorgenes tumornames tumdata] = readmatwlabels(tumname,1);
  normname = [currdir alldatasets{i} '.normal.txt'];
fprintf('loading normal data\n');
  [normgenes normnames normdata] = readmatwlabels(normname);
  [genes IT IN] = intersect(str2double(tumorgenes),str2double(normgenes));
  if (length(genes) > 0)
  d1{i}.tumornames = tumornames;
  d1{i}.normalnames = normnames;
  d1{i}.tumordata = tumdata(IT,:);
  d1{i}.normaldata = normdata(IN,:);
  d1{i}.genes = str2double(tumorgenes(IT));
  d1{i}.name = alldatasets{i};
  d1{i}.type = allnames{i}
  d1{i}.data = real(normalize_expr_data(d1{i}.tumordata,d1{i}.normaldata));
end;