for i = 1:1255
 cmd = ['submitjob 1 -m 5 /opt/sw/morrislab/matlab2009b/bin/matlab -r "run_one_patient ' num2str(i) '"'];
end;

load alldata_for_mirna_selection.mat
[ngenes ID IN] =  intersect(genes,net.genes);
network = full(net.data(IN,:));
mirna_sel = zeros(153,size(alldata,2));
for ii = 1:size(alldata,2)
	fprintf('patient %d\n',ii);
	currdata = full(alldata(:,ii));
  	CVerr = cvglmnet(network,full(alldata(:,ii)),10,[],'response','gaussian',glmnetSet,0);
%glmnet(full(network),full(expr.data(:,ii)));
	ind =  find(CVerr.glmnet_object.lambda == CVerr.lambda_min)
	mirna_sel(:,ii) = CVerr.glmnet_object.beta(:,ind);
%    ind = find(CVerr.stderr == min(CVerr.stderr))
%    mirna_sel(find(CVerr.glmnet_object.beta(:,ind)),ii) = 1;
end
 