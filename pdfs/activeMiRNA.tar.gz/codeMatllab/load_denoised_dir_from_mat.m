function d1 = load_denoised_dir_from_mat(dirnum)

filename = ['/home/anna/cannet/director/dir' num2str(dirnum) 'profiles.denoised.mat'];
load(filename);
d1.normaldata = normaldata;
d1.tumordata = data{92};
d1.genenames = genenames;
d1.genes = genes;
d1.tumornames = tumornames;