function run_one_patient(patient,alpha)

addpath(genpath('~/cannet/'));

if (ischar(patient))
  patient = str2double(patient);
end;

if (ischar(alpha))
  alpha = str2double(alpha);
end;

load all_directors_data.mat
%load pan_alldata_new.mat

currdata = alldata(:,patient);
opts.alpha = alpha;
options = glmnetSet(opts)
full_net = full(full_net);
fit  = glmnet(full_net,currdata,'gaussian',options);
Mb = model_selection(fit,currdata);
res.beta = Mb.beta;
res.df = Mb.df;
res.dev = Mb.dev;
res.lambda = Mb.lambda;
res.genes = genes;
res.expr = currdata;
filename = ['/home/projects/morrislab/cancernetwork/bioinformatics_revision/cfr2/director_results/dir_ego_patient' num2str(patient) '_a' num2str(alpha) '.mat'];
%filename = ['/home/projects/morrislab/cancernetwork/bioinformatics_revision/cfr2/pan/fd_results/pan_fd_patient' num2str(patient) '.mat'];
save(filename,'res');

if (0)
%minds = [8 9 21 25 27 28 42 46 52 53 55 74];
 for i = 181:271%size(alldata,2)
  for alpha = 0.1:0.1:0.9
  cmd = ['submitjob 3 -m 10 /opt/sw/morrislab/matlab2009b/bin/matlab -r "run_one_patient_cannet ' num2str(i) ' ' num2str(alpha) '"'];
  fprintf('%s\n',cmd); 
  system(cmd);
  end     
 end;
end;