function [rowlabels collabels mat] = readmatwlabels(filename,startind,commentchar);
%function [rowlabels collabels mat]  = readmatwlabels(filename,startind,commentchar);
% assumes first column to be row labels and first row to be column labels

if nargin < 3
  commentchar = '#';
end;
if nargin < 2
  startind = 2;
end;
  

fprintf('%s\n',filename);

lines     = textread(filename,'%s',-1,'delimiter','\n','bufsize',1e5);
numcommentlines = 0;
while (strcmp(lines{numcommentlines+1}(1),commentchar))
  strread(lines{numcommentlines+1},'%s',-1,'delimiter','\t','bufsize',1e5);
  numcommentlines = numcommentlines+1
  lines{numcommentlines}(1)
end;
  temp = strread(lines{numcommentlines+1},'%s',-1,'delimiter','\t','bufsize',1e5);
collabels = temp(startind:end);
numrows   = length(lines)
numcols = length(collabels)

vec = '%s';
for i = 1:numcols
  vec = [vec '\t%.6f'];
end;
mat = zeros(numrows-1,numcols);


for ii = numcommentlines+2:numrows
	%we separate out nextline and the assignment to entries, so that if the user has specifically defined tablewidth to be larger than
	%the first line for example (if the last column is an optional flag), we can still read in the rest of the lines, which will not
	%be the full width of entries
	nextline = strread(lines{ii},'%s',-1,'delimiter','\t');
	rowlabels{ii-1} = strtok(nextline{1},'_');
        tmp = cellfun(@str2double,nextline(2:end));%num2str(nextline(2:end));
	if (length(tmp) < numcols)
	  tmp = [tmp;NaN];
	end;
	mat(ii-1,:) = tmp';
        
	%entries(ii,:) = strread(lines{ii},'%s',-1,'delimiter','\t');
end
rowlabels{1}

