%res = analyze_patient(expr,full_net,genes,patient,ms_type);
%Input: expr of size genes x patients
%       normalized adjacency matrix  (genes x genes)
%       genes - list of doubles (EntrezIDs)
%       patient - the number of the patient for whom to perform the analysis
%       ms_type - type of model selection ('BIC' - default, or 'CV' - 10-fold crossvalidation (slower))
%Output:  res - a structure containing
%              betas - 
function res = analyze_patient(expr,full_net,patient,ms_type)

if nargin < 4
 ms_type = 'BIC';
end;
switch ms_type
case 'BIC',
  fit = glmnet(full_net,expr(:,patient));
  [Ms Mb] = model_selection(fit,expr);
  res.beta = Mb.beta;
  res.df = Mb.df;
  res.dev = Mb.dev;
case 'CV',
  CVerr = cvglmnet(full_net,expr(:,patient),10,[],'response','gaussian',glmnetSet,0);
  ind = find(CVerr.stderr == min(CVerr.stderr));
  res.beta = CVerr.glmnet_object.beta(:,ind);
  res.dev = CVerr.glmnet_object.dev(ind);
  res.df = CVerr.glmnet_object.df(ind);
otherwise 
  res = [];
  fprintf('We do not support such model selection type\n');
end;
