function run_one_patient(patient)

addpath(genpath('~/cannet/code/matlab/'));

if (ischar(patient))
  patient = str2double(patient);
end;
load ../alldata_for_mirna_selection.mat
[ngenes ID IN] =  intersect(genes,net.genes);
network = full(net.data(IN,:));

currdata = full(alldata(:,patient))-mean(alldata(:,patient));
CVerr = cvglmnet(network,currdata,10,[],'response','gaussian',glmnetSet,0);
filename = ['../nonstd_alldata_patient' num2str(patient) '.mat'];
save(filename,'currdata','network','genes','CVerr');
cmd = ['submitjob 1 -m 5 /opt/sw/morrislab/matlab2009b/bin/matlab -r "get_fit_bhatt ' num2str(i) ' ' num2str(j) '"'];