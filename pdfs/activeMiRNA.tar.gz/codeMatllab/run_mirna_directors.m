function run_mirna_directors(MF,AL,numdir,exprN,names)
annotfilename = ['~/cannet/director/director' num2str(numdir) '.annotation.txt']
mirna_sel_ind = find(MF(:,2) > 215);
mirna_sel_ind = mirna_sel_ind([1:8 10 12]); 
Annot = load_annotation_data(annotfilename,60);
Data.sampids = exprN{numdir}.tumornames;
Data.genenames = names;
prefix = ['dir' num2str(numdir) '_mirna'];
print_surv_for_selection_of_genes(Data,AL{numdir},[],mirna_sel_ind,Annot,prefix)