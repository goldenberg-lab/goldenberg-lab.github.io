d1 = load('director1.mat');
net = load('glment_input');

fx = lookup(net.network.rowlabels,d1.genes);
xx = find(~isnan(fx));

exprN = normalize_expr_data(d1.tumordata,d1.normaldata);
expr.data = exprN(fx(xx),:);
expr.tumor = d1.tumornames;
expr.rowlabels = d1.genes(fx(xx));
network = net.network.data;

for ii = 1:size(expr.data,2);
    results_dir1{ii} = glmnet(full(network),full(expr.data(:,ii)));
end

d1 = load('director2.mat');
net = load('glment_input');

fx = lookup(net.network.rowlabels,d1.genes);
xx = find(~isnan(fx));

exprN = normalize_expr_data(d1.tumordata,d1.normaldata);
expr.data = exprN(fx(xx),:);
expr.tumor = d1.tumornames;
expr.rowlabels = d1.genes(fx(xx));
network = net.network.data;

for ii = 1:size(expr.data,2);
    results_dir2{ii} = glmnet(full(network),full(expr.data(:,ii)));
end

d1 = load('director3.mat');
net = load('glment_input');

fx = lookup(net.network.rowlabels,d3.genes);
xx = find(~isnan(fx));

exprN = normalize_expr_data(d3.tumordata,d3.normaldata);
expr.data = exprN(fx(xx),:);
expr.tumor = d3.tumornames;
expr.rowlabels = d3.genes(fx(xx));
network = net.network.data;

for ii = 1:size(expr.data,2);
    results_dir3{ii} = glmnet(full(network),full(expr.data(:,ii)));
end