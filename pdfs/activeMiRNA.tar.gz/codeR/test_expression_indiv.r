test_expression_indiv=function(indiv,mirna,exprN,exprMi){
confirm=rep(0,dim(resmirna$mirna)[1]);
   predicted=rep(0,dim(resmirna$mirna)[1]);
   confirmmirna=rep("",dim(resmirna$mirna)[1]);
   confirmmirnaorigin=rep("",dim(resmirna$mirna)[1]);
   v=1;
for (w in 1:dim(indiv)[1]){
type=substring(mirna[w],1,3);
ind=substring(mirna[w],5);
maxconfirm=-1;
maxmirna="";

str=unlist(strsplit(ind, "/"));
for (i in 1:length(str)){
	cmirna=paste(type, "-",str[i], sep='');
	j= which(exprMi==cmirna);
	confirmation=0;
	if (length(j)==0){
        indnonnumeric=suppressWarnings(is.na(as.numeric(substring(exprMi,nchar(exprMi))))) ;
        j= which(substring(exprMi,1,nchar(exprMi)-1)==cmirna & indnonnumeric);
	}
	if (length(j)>0){
        for (u in 1:length(j)){
                confirmation=length(which(exprN[j[u],]*indiv[w,]<0))/length(which(indiv[w,]!=0));
                prediction= length(which(indiv[w,]!=0))/length(indiv[w,]);
		print(paste(cmirna," = ",exprMi[j[u]],"confirmed at",confirmation," predicted in ", 				prediction));
                print(paste( "prediction computed over ",length(which(indiv[w,]!=0) ) ));
		if (maxconfirm<confirmation){maxconfirm=confirmation;maxmirna=cmirna;}
		#print(exprN[j[u],]);
        }
	}
         else print(paste(cmirna, "not found"));

}
if(maxmirna!=""){
	confirm[v]=maxconfirm;
	predicted[v]=prediction;
	confirmmirna[v]=maxmirna;
        confirmmirnaorigin[v]=mirna[w];
	v=v+1;
	}

}
return(cbind(confirmmirna[1:(v-1)], confirm[1:(v-1)],predicted[1:(v-1)] ,confirmmirnaorigin[1:(v-1)] ) );


}
