#datapath="data/glioblastoma/Expression-Genes/UNC__AgilentG4502A_07_1/Level_3/";output="glioblastoma_gene_agilent";sub1=30;sub2=30;
#datapath="data/glioblastoma/Expression-Genes/UNC__AgilentG4502A_07_2/Level_3/";output="glioblastoma_gene_agilent2";sub1=30;sub2=30;
datapath="data/glioblastoma/Expression-Genes/BI__HT_HG-U133A/Level_3/";output="glioblastoma_gene_broad";sub1=29;sub2=30;##29,30
#datapath="data/glioblastoma/Expression-miRNA/UNC__H-miRNA_8x15K/Level_3/";output="glioblastoma_mirna_hmirna"; sub1=25;sub2=31;#25,31

files=list.files(datapath);

x=read.table(paste(datapath,files[1],sep=''),skip=1,colClasses = c("NULL", "factor", "double"),quote = "",na.strings = "null" );
data= matrix(0,dim(x)[1],length(files));
colnames(data) <- substring(files,sub1,nchar(files)-sub2);
rownames(data) <-x[,1];
data[,1]=as.vector(x[,2]);
controlIndexes=which(substr(colnames(data),14,14)=="1");
patientsNames=as.vector(read.table("data/glioblastoma/patientID.txt"));
patientIndexes=NULL;
for (i in 1:dim(data)[2]){
for (j in 1:length(patientsNames)){
if (substr(colnames(data)[i],1,19)==patientsNames[j])patientIndexes=c(patientIndexes,i);
}
}

for (i in 2:length(files)){
x=read.table(paste(datapath,files[i],sep=''),skip=1,colClasses = c("NULL", "NULL", "double"),quote = "",na.strings = "null");
data[,i]=x[,1];
}

controldata=data[,controlIndexes];
patientdata=data[,patientIndexes];

write.table(patientdata, paste(output,"_cases.txt",sep=""),row.names=FALSE);
write.table(controldata, paste(output,"_controls.txt",sep=""),row.names=FALSE);
#write(rownames(data), paste(output,"_index.txt",sep=""));

