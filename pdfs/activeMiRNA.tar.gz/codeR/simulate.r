simulate=function(net,protnet,protnetsq,choice,diffusion,multiplier,multiplier2=0,noisemrna=2,mrnabias=0.001){
nbpatients=5;
mirsize=30;
minexp=1.5;
maxexp=4;
maxbias=0.001;
noise1=0.5;
noise2=0.5;
multiplier2current=multiplier2;
if (multiplier2current==0)multiplier2current==multiplier;
addededgeproba=0.003*multiplier;
removededgeproba=0.05*multiplier2current;

select=sample(length(net$mirnas),mirsize);
rest=setdiff(1:length(net$mirnas), select);

mirExp= matrix(0,length(net$mirnas), nbpatients);
for (i in 1:mirsize){
sign=runif(1,-1,1);
if (sign!=0) sign=sign/abs(sign);
mirExp[select[i],]= rnorm(nbpatients,0,noise1*sqrt(abs(mean(mirExp[select[i],]))))+ sign*runif(1,minexp,maxexp)
}
for (i in 1:length(rest)){
sign=runif(1,-1,1);
if (sign!=0) sign=sign/abs(sign);
mirExp[rest[i],]= rnorm(nbpatients,0,noise2*sqrt(abs(mean(mirExp[rest[i],]))))+ sign*runif(1,0,maxbias)
}

#add net noise 
remov=matrix( rbern( dim(net$data)[1]*dim(net$data)[2], 1-removededgeproba) , dim(net$data)[1], dim(net$data)[2] );
adding=matrix(rbern(dim(net$data)[1]*dim(net$data)[2], addededgeproba), dim(net$data)[1], dim(net$data)[2] );
netreal= remov*net$data+ adding;
netreal= netreal/(netreal+0.00000000000000000000000001);
x=(net$data-netreal);
edgeadded=length(which(x==-1))/length(which(net$data==1));
edgeremoved=length(which(x==1))/length(which(net$data==1));
print( paste( edgeadded," of edges added, ", edgeremoved, " removed"));

#mRNA computaion
mrExp=-netreal%*%mirExp;
#add mRNA noise
for (i in 1:dim(mrExp)[1]){
mu=runif(1,-1,1);
mrExp[i,]=mrExp[i,]/4+ rnorm(nbpatients,mu*mrnabias,noisemrna*sqrt(abs(mean(mrExp[i,]/4))));#*sqrt(abs(mean(mrExp[i,]/4)))
}

#add mrna/mrna interaction noise
mrExp=(diag(dim(protnet)[1])+diffusion*protnet+diffusion*diffusion*protnetsq)%*%mrExp;



resbetas = matrix(0,length(net$data[1,]),length(mrExp[1,]));
resdev=rep(NA, length(mrExp[1,]));
resdf=rep(NA, length(mrExp[1,]));
sensitivities=rep(0, length(mrExp[1,]));
confirmations=rep(0, length(mrExp[1,]));
precisions=rep(0, length(mrExp[1,]));
network=net$data;#/sqrt(rowSums(net$data));
#print(net$mirnas[select]);

for (ii in 1:length(mrExp[1,])){
    if (1){
    CVerr = cv.glmnet(as.matrix(network),as.matrix(mrExp[,ii]),alpha=0.5);
    } else {
    #using sparse matrix : do not work because of cv.glmnet problem
    #mat=as.matrix(network);
    #spars=sparseMatrix(1+(which(mat==1)-1)%%dim(mat)[1],  1+(which(mat==1)-1)%/%dim(mat)[1]);
    #CVerr = cv.glmnet(spars, as.matrix(expr$data[,ii]));
    }
    ind1 = which(CVerr$cvm==min(CVerr$cvm));#stderr  choose CVerr$cvm==min(CVerr$cvm)  or CVerr$lambda==CVerr$lambda.1se
    ind2=which(CVerr$lambda==CVerr$lambda.1se); 
    bestnargs = abs(CVerr$nzero-mirsize);
    ind3= which(bestnargs==min(bestnargs));
    
    print(paste("Lamba index = ",ind1," or ",ind2[1]," or ",ind3[1]));
    #choice of lambda
    if (choice==1)ind=ind1;#min error
    if (choice==2)ind=ind2[1];# 1 standard error before min
    if (choice==3)ind=ind3[1];#based on wanted nb non null
    resbetas[,ii] = CVerr$glmnet.fit$beta[,ind];
    resdev[ii] = CVerr$glmnet.fit$dev.ratio[ind];#dev
    resdf[ii] = CVerr$glmnet.fit$df[ind];
    detected=intersect(select,which(resbetas[,ii]!=0));
    if (length(detected)>1){
        sensitivities[ii]=length(detected)/mirsize;
        confirmed=which(resbetas[detected,ii]/rowMeans(mirExp[detected,])<0);
        confirmations[ii]=length(confirmed)/length(detected);
        precisions[ii]=length(detected)/length(which(resbetas[,ii]!=0));
        print(paste("Sensitivity :", sensitivities[ii]));
        print(paste("Confirmed proportion :", confirmations[ii]));
        print(paste("Precision :", precisions[ii] ));
        #print(paste("accuracy :", mean(abs(  1-resbetas[detected,ii]/(rowMeans(mirExp[detected,])+0.0000000000001)  ) ) ));
    }
}

return (list(sensitivity=sensitivities,confirmation=confirmations, precision=precisions));
}



