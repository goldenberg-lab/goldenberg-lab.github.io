interesting_mirna=function(betas,mirnas){
occurences=matrix(0,dim(betas)[1],4);
for (i in 1:dim(betas)[1]){
occurences[i,1]=length(which(betas[i,]>0))/length(betas[i,]);
occurences[i,2]=length(which(betas[i,]<0))/length(betas[i,]);
occurences[i,4]=mean(betas[i,]);
}
occurences[,3]=abs(occurences[,2]-occurences[,1]);
x=which(occurences[,3]>0.1);
y=as.matrix(mirnas)
return (list(mirna=cbind(y[x,1],occurences[x,]), indiv=betas[x,] , indivrna=y[x,],indexes=x ))


}
