load_couple=function(currdir,dataname,tumorfile,normalfile){
print("loading tumordata data\n");
  tumname = paste(currdir,dataname,tumorfile,sep='');
  labels = readmatwlabels(tumname,2);
  tumorgenes =labels$genes;
  tumornames =labels$names;
  tumdata = labels$data;
  goodtumorgenes=as.vector(tumorgenes);
goodtumorgenesindex=1:length(goodtumorgenes);
normgenes=NULL;
normnames=NULL;
normdata=NULL;
goodnormgenes=NULL;
if (normalfile!=''){
normname = paste(currdir,dataname, normalfile,sep='');
print("loading normal data\n");
   labels= readmatwlabels(normname);
   normgenes =labels$genes;
   normnames =labels$names;
   normdata =labels$data;
goodnormgenes=as.vector(normgenes);

goodnormgenesindex=1:length(goodnormgenes);
if(nchar(goodnormgenes[1])>3 &&  substring(goodnormgenes[1],nchar(goodnormgenes[1])-2)=='_at'){
print ("converting gene names...\n");
goodnormgenesindex=convertGeneDouble(goodnormgenes);
goodnormgenes=goodnormgenes[goodnormgenesindex];
goodnormgenes=substring(goodnormgenes,1,nchar(goodnormgenes)-3);
}
}
if(nchar(goodtumorgenes[1])>3 &&  substring(goodtumorgenes[1],nchar(goodtumorgenes[1])-2)=='_at'){
print ("converting gene names..\n");
goodtumorgenesindex=convertGeneDouble(goodtumorgenes);
goodtumorgenes=goodtumorgenes[goodtumorgenesindex];
goodtumorgenes=substring(goodtumorgenes,1,nchar(goodtumorgenes)-3);
}
if (length(goodnormgenes)>1 && !is.na(as.double(goodnormgenes[2]))){
goodnormgenes=as.double(goodnormgenes);
goodtumorgenes=as.double(goodtumorgenes);
}

return (list(tumorgenes = goodtumorgenes, tumornames =tumornames,tumdata =tumdata[goodtumorgenesindex,], normgenes = goodnormgenes, normnames =normnames,normdata =normdata[goodnormgenesindex,]));
}
