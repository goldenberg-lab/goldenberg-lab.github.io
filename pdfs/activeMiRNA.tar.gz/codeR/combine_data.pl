#! /usr/bin/perl

@allfiles = `ls *mirna*`;
for ($i = 1; $i <= $#allfiles; $i++) {
#print $allfiles[$i],"\n";
    open(IN," < $allfiles[$i]");
    while(<IN>) {
    		chomp(($dummy,$gene,$val) = split /\t/,$_);
		$hash{$gene}[$i] = $val;
		$names[$i] = $dummy;
     }
     close(IN);
}
print id." ";
print "@names";
foreach $gene (keys %hash) {
  print "$gene @{ $hash{$gene} }";
  print "\n";
}
