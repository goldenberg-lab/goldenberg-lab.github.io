#!/bin/bash
#$ -pe agoldenb 16
#$ -N simulate1
#$ -M azizmezlini@yahoo.fr
#$ -m bea 
#$ -l mem_free=20380m
cd /home/mezlinim/mirna
/tools/R/2.13.2/bin/Rscript --no-save --no-restore codeR/simulateAll.r    > output.txt 2>log.txt

