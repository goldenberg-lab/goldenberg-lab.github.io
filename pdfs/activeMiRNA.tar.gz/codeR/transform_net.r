mrna= as.matrix(read.table("../../Downloads/mrnafinal"));
mirna= as.matrix(read.table("../../Downloads/mirnafinal"));
matr= as.matrix(read.table("../../Downloads/mirnagenefinalscore"));

net=matrix(0, length(mrna), length(mirna));

mirname="";
line=1; 
mi=0;
while (line<dim(matr)[1]){
   if (matr[line,1]!=mirname){       
	mirname=matr[line,1];
	mi=mi+1;
   }
   ind=which(mrna==as.integer(matr[line,2]));
   if (length(ind)==0) {
	print("not found");
   } else if(length(ind)>1){
	print("found several");
        print(ind);
   } else {
      net[ind,mi]=net[ind,mi]+1;
   }

   line=line+1;
}

