#datapath="data/serousCystadenocarcinoma/Expression-Genes/UNC__AgilentG4502A_07_3/Level_3/";output="cystadeno_gene_agilent3";sub1=30;sub2=30;
#datapath="data/serousCystadenocarcinoma/Expression-Genes/UNC__AgilentG4502A_07_2/Level_3/";output="cystadeno_gene_agilent2";sub1=30;sub2=30;
#datapath="data/serousCystadenocarcinoma/Expression-Genes/BI__HT_HG-U133A/Level_3/";output="cystadeno_gene_broad";sub1=29;sub2=30;##29,30
datapath="data/serousCystadenocarcinoma/Expression-miRNA/UNC__H-miRNA_8x15Kv2/Level_3/";output="cystadeno_mirna_hmirna"; sub1=27;sub2=31;#25,31

files=list.files(datapath);

x=read.table(paste(datapath,files[1],sep=''),skip=1,colClasses = c("NULL", "factor", "double"),quote = "",na.strings = "null" );
data= matrix(0,dim(x)[1],length(files));
colnames(data) <- substring(files,sub1,nchar(files)-sub2);
rownames(data) <-x[,1];
data[,1]=as.vector(x[,2]);
controlIndexes=which(substr(colnames(data),14,14)=="1");
patientIndexes=setdiff(1:length(colnames(data)), controlIndexes);

for (i in 2:length(files)){
x=read.table(paste(datapath,files[i],sep=''),skip=1,colClasses = c("NULL", "NULL", "double"),quote = "",na.strings = "null");
data[,i]=x[,1];
}

controldata=data[,controlIndexes];
patientdata=data[,patientIndexes];

write.table(patientdata, paste(output,"_cases.txt",sep=""));
write.table(controldata, paste(output,"_controls.txt",sep=""));
#write(rownames(data), paste(output,"_index.txt",sep=""));

