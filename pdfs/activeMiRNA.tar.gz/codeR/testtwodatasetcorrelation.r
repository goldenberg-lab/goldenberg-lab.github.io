datasets = c('GSE10810', 'GSE10927', 'GSE11024', 'GSE11151', 'GSE12368', 'GSE13601', 'GSE13911', 
	'GSE14001', 'GSE15471', 'GSE16515','GSE19826', 'GSE23878', 'GSE6631', 'GSE7904', 'GSE8607',
'GSE8671', 'GSE9348', 'GSE9844');
datanames = c('Breast','Adrenocortical','Renal','Renal mixed','Adrenocortical','Tongue SSC','Gastric','Ovarian','Pancreatic','Pancreatic','Gastric','Colorectal','HeadNeck SSC','Breast','Testicular','Colorectal Ad','Colorectal','Tongue SSC');
datasets = c('GSE10072', 'GSE13597', 'GSE15852', 'GSE6008', 'GSE10810', 'GSE10927', 'GSE11024', 'GSE11151', 'GSE12368', 'GSE13601', 'GSE13911',  'GSE14001', 'GSE15471', 'GSE16515','GSE19826', 'GSE23878', 'GSE6631', 'GSE7904', 'GSE8607', 'GSE8671', 'GSE9348', 'GSE9844');
#'GSE3167', 'GSE12907', 'GSE15641', 'GSE21122'
normalize=1;
dataset1="GSE13597";
#dataset2='GSE13601';

library(R.matlab)
library(Matrix)
source("codeR/load_mirna_net.r")
source("codeR/readmatwlabels.r")
source("codeR/run_mirna_one_ds.r")
source("codeR/normalize_expr_data.r")
source("codeR/load_couple.r")
source("codeR/convertGeneDouble.r")
source("codeR/interesting_mirna.r")
source("codeR/test_expression.r")
source("codeR/test_expression_indiv.r")
source("codeR/coherence_estimation.r")

library(glmnet)

#net = load_mirna_net();
netread=read.table("newnet3",check.names=FALSE);
net=list(genes=rownames(netread), mirnas = substring(colnames(netread),5), data = as.matrix(netread));

currdir = 'data/preisolated_data/';
cancersuffix='.cancer.txt';

nbtrials=length(datasets);
#nbtrials=15;
corrmeans=matrix(0,nbtrials,nbtrials);
corrsds=matrix(0,nbtrials,nbtrials);

for (k in 1:nbtrials){

dataset1=datasets[k];

for(j in 1:nbtrials){

dataset2=datasets[j];


 loaded=load_couple(currdir,dataset1,cancersuffix,'.normal.txt');
   resIntersect = intersect(loaded$tumorgenes,loaded$normgenes);#str2double
   resgenes = sort(resIntersect);
   IT=as.vector(match(resgenes,loaded$tumorgenes));
   IN=as.vector(match(resgenes,loaded$normgenes));
	d1 =list(normaldata=loaded$normdata[IN,], tumordata=loaded$tumdata[IT,], 
	        normalnames = loaded$normnames, genes = loaded$tumorgenes[IT], 
		tumornames = loaded$tumornames)#str2double



 loaded2=load_couple(currdir,dataset2,cancersuffix,'.normal.txt');
   resIntersect = intersect(loaded2$tumorgenes,loaded2$normgenes);#str2double
   resgenes = sort(resIntersect);
   IT=as.vector(match(resgenes,loaded2$tumorgenes));
   IN=as.vector(match(resgenes,loaded2$normgenes));
	d2 =list(normaldata=loaded2$normdata[IN,], tumordata=loaded2$tumdata[IT,], 
	        normalnames = loaded2$normnames, genes = loaded2$tumorgenes[IT], 
		tumornames = loaded2$tumornames)#str2double

resIntersect = intersect(d1$genes,d2$genes);#str2double
   resgenes = sort(resIntersect);
   IT=as.vector(match(resgenes,d1$genes));
   IN=as.vector(match(resgenes,d2$genes));
	d11 =list(normaldata=d1$normaldata[IT,], tumordata=d1$tumordata[IT,], 
	        normalnames = d1$normalnames, genes = d1$genes[IT], 
		tumornames = d1$tumornames)#str2double
	d22 =list(normaldata=d2$normaldata[IN,], tumordata=d2$tumordata[IN,], 
	        normalnames = d2$normalnames, genes = d2$genes[IN], 
		tumornames = d2$tumornames)#str2double

matrice1=d11$tumordata;
matrice2=d22$tumordata;
if (normalize){
matrice1 = normalize_expr_data(d11$tumordata,d11$normaldata,1);
matrice2 = normalize_expr_data(d22$tumordata,d22$normaldata,1);
}


corr=rep(0,length(matrice1[,1]));
for (i in 1:length(matrice1[,1])){
corr[i]= (var(matrice1[i,])+var(matrice2[i,]))/ var(c(matrice1[i,],matrice2[i,]))
}
corrmeans[k,j]=mean(corr);
corrsds[k,j]=sd(corr);
}
}
print(corrmeans)


