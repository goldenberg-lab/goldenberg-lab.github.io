coherence_estimation=function(exprN){

l=length(exprN[1,]);
coherence=rep(0,length(exprN[,1]));
for (u in 1:length(exprN[,1])){
same=max(c(length(which(exprN[u,]>0)), length(which(exprN[u,]<0))))/l;
coherence[u]=same;
}
print(paste(" Average ", mean(coherence)));
print(paste(" Over 80% coherent",length(which(coherence>0.8))/length(coherence)));

return(coherence);
}
