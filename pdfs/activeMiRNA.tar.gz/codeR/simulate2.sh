#!/bin/bash
#$ -pe agoldenb 16
#$ -N simulate2
#$ -M azizmezlini@yahoo.fr
#$ -m bea 
#$ -l mem_free=20380m
cd /home/mezlinim/mirna
/tools/R/2.13.2/bin/Rscript --no-save --no-restore codeR/simulateAll2.r    >output2.txt 2>log2.txt

