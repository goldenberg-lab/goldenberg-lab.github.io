datapath="data/glioblastoma/Expression-miRNA/UNC__H-miRNA_8x15K/Level_3/"
files=list.files(datapath);

x=read.table(paste(datapath,files[1],sep=''),skip=1,colClasses = c("NULL", "factor", "double"),quote = "",na.strings = "null" );
data= matrix(0,dim(x)[1],length(files));
colnames(data) <- substring(files,25,nchar(files)-31);
rownames(data) <-x[,1];
data[,1]=as.vector(x[,2]);


for (i in 2:length(files)){
x=read.table(paste(datapath,files[i],sep=''),skip=1,colClasses = c("NULL", "NULL", "double"),quote = "",na.strings = "null");
data[,i]=x[,1];
}


output="glioblastoma_mirna_hmirna";
write.table(data, paste(output,".txt",sep=""),row.names=FALSE);
write(rownames(data), paste(output,"_index.txt",sep=""));

