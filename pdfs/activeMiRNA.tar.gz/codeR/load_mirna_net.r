load_mirna_net = function(){

#newD=readMat('data/mirna_network_notnorm.mat');#or may be res= and then use res$newD
#net = list(genes=newD$rowlabels, mirnas = newD$collabels, data = newD$data);
genesmat=read.table('data/mirna_network_gene.txt');
datamat=read.table('data/mirna_network_data.txt');
rowmat=read.table('data/mirna_network_row.txt');
colmat=read.table('data/mirna_network_col.txt');
net = list(genes=rowmat, mirnas = colmat, data = datamat);


return(net);
}
