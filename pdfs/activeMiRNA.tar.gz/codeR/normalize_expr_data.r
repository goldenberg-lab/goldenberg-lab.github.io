#Normalizing data according to SAM (tibshirani et al, 2002)
#function expr = normalize_expr_data(tumor,normal)
normalize_expr_data= function(tumor,normal,logtumflag,meanflag){

recenter=1;
recenterafter=0;
nargs()
if (nargs() < 3){
logtumflag = 0;
 if (max(tumor)<30 || min(tumor)<0){
logtumflag=1;
}
}
if (nargs() < 4){
 meanflag = 1;
} else{
 meanflag = 0;
}

if (max(normal)>30 && min(normal)>=0){
normal = log2(normal);
}

if (!logtumflag){
'taking the log';
  tumor = log2(tumor);
}
mean_norm = rowMeans(normal);#along dim 2 in matlab
numtumor = length(tumor[1,]);#along dim 2 in matlab
numnorm = length(normal[1,]);#along dim 2 in matlab

expr = (tumor-matrix(as.matrix(mean_norm),length(mean_norm),numtumor));

if (recenter && !recenterafter){
z=rep(0,dim(expr)[2]);
for (h in 1 : dim(expr)[2]){
   nonnull= expr[which(is.na(expr[,h])==FALSE),h];
   dens=density(nonnull)
   indmode=dens$x[which(dens$y==max(dens$y)) ];
   z[h]=(indmode);
   expr[,h]=expr[,h]-indmode;
}
print (mean(abs(z)))
tumor=expr+matrix(as.matrix(mean_norm),length(mean_norm),numtumor);
}


if (meanflag){
  mean_tumor = rowMeans(tumor);#along dim 2 in matlab
}

stds =apply(normal,1,sd);#along dim 2 in matlab
a = (1/numtumor+1/numnorm)/(numtumor+numnorm-2);
s_i = rowSums( (normal-matrix(as.matrix(mean_norm),length(mean_norm),numnorm))^2) +rowSums((tumor-matrix(as.matrix(mean_tumor),length(mean_tumor),numtumor))^2);#along dim 2 in matlab
s_i = sqrt(a*s_i);
if (0){
d_i = (mean_tumor-mean_norm)/s_i;
        x = 0:.1:100;
        for (i in 1:length(x)){
        ffxi = (mean_female-mean_norm)/(s_i_f+x(i));
                fmxi = (mean_male-mean_norm)/(s_i_m+x(i));
                std_ffxi(i) = std(ffxi);
                mean_ffxi(i) = mean(ffxi);
                std_fmxi(i) = std(fmxi);
                mean_fmxi(i) = mean(fmxi);
                diffxi(i) = abs(std_ffxi/mean_ffxi-std_fmxi/mean_fmxi);
        }
        which(diffxi == min(diffxi))
}

expr=expr/matrix(as.matrix(s_i+1),length(s_i),numtumor);

if (recenter && recenterafter){
z=rep(0,dim(expr)[2]);
for (h in 1 : dim(expr)[2]){
   nonnull= expr[which(is.na(expr[,h])==FALSE),h];
   dens=density(nonnull)
   indmode=dens$x[which(dens$y==max(dens$y)) ];
   z[h]=(indmode);
   expr[,h]=expr[,h]-indmode;
}
print (mean(abs(z)))
}

return (expr);
}
