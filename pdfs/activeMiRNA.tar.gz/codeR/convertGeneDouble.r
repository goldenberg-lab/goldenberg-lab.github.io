convertGeneDouble=function(genes){
#remove the _at and convert to double

goodgenes=rep(NA,length(genes));
v=1;
for (u in 1:length(genes)){
x=as.double(substring(genes[u],1,nchar(genes[u])-3));
if (!is.na(x)){
goodgenes[v]=u;
v=v+1;
}
}

goodgenes=goodgenes[1:v-1];

return (goodgenes);
}
