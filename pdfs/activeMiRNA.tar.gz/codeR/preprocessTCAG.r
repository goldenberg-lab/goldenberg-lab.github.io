#datapath="data/glioblastoma/Expression-Genes/UNC__AgilentG4502A_07_1/Level_3/";
#datapath="data/glioblastoma/Expression-Genes/UNC__AgilentG4502A_07_2/Level_3/";#30,30
datapath="data/glioblastoma/Expression-Genes/BI__HT_HG-U133A/Level_3/";#29,30
#datapath="data/glioblastoma/Expression-miRNA/UNC__H-miRNA_8x15K/Level_3/" #25,31

files=list.files(datapath);

x=read.table(paste(datapath,files[1],sep=''),skip=1,colClasses = c("NULL", "factor", "double"),quote = "",na.strings = "null" );
data= matrix(0,dim(x)[1],length(files));
colnames(data) <- substring(files,29,nchar(files)-30);
rownames(data) <-x[,1];
data[,1]=as.vector(x[,2]);


for (i in 2:length(files)){
x=read.table(paste(datapath,files[i],sep=''),skip=1,colClasses = c("NULL", "NULL", "double"),quote = "",na.strings = "null");
data[,i]=x[,1];
}

#output="glioblastoma_gene_agilent";
#output="glioblastoma_gene_agilent2";
output="glioblastoma_gene_broad";
#output="glioblastoma_mirna_hmirna";
write.table(data, paste(output,".txt",sep=""),row.names=FALSE);
write(rownames(data), paste(output,"_index.txt",sep=""));

