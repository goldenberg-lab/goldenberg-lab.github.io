 #load directors
if (0){
for (i in 1:4){
 i
 sprintf('loading net...\n');
 net = load_mirna_net(); 
 sprintf('loading data...\n');
 d1 = load_denoised_dir_from_mat(i);
 sprintf('analyzing...\n');
 res[i] = run_mirna_one_ds(d1,net);
}
}

clean=0;
mirnadatasets = c('preprocessed/mskcc');#preprocessed/mskcc glioblastoma/glioblastoma_broad serousCystadenocarcinoma/cystadeno_broad liverData/GSE22058 ../../data/breast_cancer/final/breast

datasets = c('GSE10810', 'GSE10927', 'GSE11024', 'GSE11151', 'GSE12368', 'GSE13601', 'GSE13911', 
	'GSE14001', 'GSE15471', 'GSE16515','GSE19826', 'GSE23878', 'GSE6631', 'GSE7904', 'GSE8607',
'GSE8671', 'GSE9348', 'GSE9844');

alldatasets = c('GSE10072', 'GSE13597', 'GSE15852', 'GSE3167', 'GSE12907', 'GSE15641', 'GSE21122', 'GSE6008', 'GSE10810', 'GSE10927', 'GSE11024', 'GSE11151', 'GSE12368', 'GSE13601', 'GSE13911', 
        'GSE14001', 'GSE15471', 'GSE16515','GSE19826', 'GSE23878', 'GSE6631', 'GSE7904', 'GSE8607',
'GSE8671', 'GSE9348', 'GSE9844');

datanames = c('Breast','Adrenocortical','Renal','Renal mixed','Adrenocortical','Tongue SSC',
'Gastric','Ovarian','Pancreatic','Pancreatic','Gastric','Colorectal','HeadNeck SSC',
'Breast','Testicular','Colorectal Ad','Colorectal','Tongue SSC');

#library(R.matlab)
library(Matrix)
source("codeR/load_mirna_net.r")
source("codeR/readmatwlabels.r")
source("codeR/run_mirna_one_ds.r")
source("codeR/normalize_expr_data.r")
source("codeR/load_couple.r")
source("codeR/convertGeneDouble.r")
source("codeR/interesting_mirna.r")
source("codeR/test_expression.r")
source("codeR/test_expression_indiv.r")
source("codeR/coherence_estimation.r")

library(glmnet)

#net = load_mirna_net();
netread=read.table("newnet3",check.names=FALSE);
net=list(genes=rownames(netread), mirnas = substring(colnames(netread),5), data = as.matrix(netread));

currdir = 'data/';
ind = 1;
moreres=array(list(), length(mirnadatasets));
confirmation=NULL;
i=1;
for (i in 1:length(mirnadatasets)){
   i
   loaded=load_couple(currdir,mirnadatasets[i],'.log2profbeta.txt','.normal.txt');
   resIntersect = intersect(loaded$tumorgenes,loaded$normgenes);#str2double
   resgenes = sort(resIntersect);
   IT=as.vector(match(resgenes,loaded$tumorgenes));
   IN=as.vector(match(resgenes,loaded$normgenes));

  # if (length(resgenes) > 0){
	d1 =list(normaldata=loaded$normdata[IN,], tumordata=loaded$tumdata[IT,], 
	        normalnames = loaded$normnames, genes = loaded$tumorgenes[IT], 
		tumornames = loaded$tumornames)#str2double
	sprintf('analyzing...\n');
	prediction = run_mirna_one_ds(d1,net);
	moreres[[ind]]=prediction;
	ind = ind+1;
 # }
}
if (0){#predicting cancer types
y=NULL;
allbetas=NULL;
for (i in 1:length(moreres)){
y=c(y,rep(i,length(moreres[[i]]$betas[1,])));
allbetas=cbind(allbetas,moreres[[i]]$betas);
}

#Optional Y per dataset
for (i in 1:length(y)){
if (y[i]<5)y[i]=1;#lung
if (y[i]==18)y[i]=5;#breast
if (y[i]==9)y[i]=6;#adenocortical
if (y[i]==8)y[i]=7;#renal
if (y[i]==22)y[i]=10;#tongue
if (y[i]==15)y[i]=11;#gastric
if (y[i]==14)y[i]=13;#pancreatic
if (y[i]==20 || y[i]==21)y[i]=16;#colorectal
}
#End optional

CVerr = cv.glmnet(t(allbetas),y,family="multinomial",type.measure="class",alpha=0.8);
allbetasmirnas=NULL;
for (i in 1:length(CVerr$glmnet.fit$beta)){
allbetasmirnas=cbind(allbetasmirnas, CVerr$glmnet.fit$beta[[i]][,67])
}
s=rowSums(allbetasmirnas/(allbetasmirnas+0.00000000000001));
print(length(which(s>0)))
print(length(which(s>1)))
net$mirnas[which(s>1)]
}#end predicting cancer types

ind=1;
   resmirna=interesting_mirna(moreres[[ind]]$betas,moreres[[ind]]$mirnas);
 resmirna$mirna[which(resmirna$mirna[,4]>0.7),]

  
   loaded2=load_couple(currdir,mirnadatasets[i],'.miRNA.log2profbeta.txt','.miRNA.normal.txt');
   
   if (clean){
   loaded$tumornames=substr(loaded$tumornames,1,16);loaded$normnames=substr(loaded$normnames,1,16);
   loaded2$tumornames=substr(loaded2$tumornames,1,16);loaded2$normnames=substr(loaded$normnames,1,16);
   }
   resIntersect = intersect(loaded2$tumorgenes,loaded2$normgenes);#str2double
   IT=as.vector(match(resIntersect,loaded2$tumorgenes));
   IN=as.vector(match(resIntersect,loaded2$normgenes));
   resIntersect = intersect(loaded2$tumornames,loaded$tumornames);#str2double
   IT2=as.vector(match(resIntersect,loaded2$tumornames));
   IN2=as.vector(match(resIntersect,loaded$tumornames));
   resIntersect = intersect(loaded2$normnames,loaded$normnames);#str2double
   IT3=as.vector(match(resIntersect,loaded2$normnames));
   IN3=as.vector(match(resIntersect,loaded$normnames));

   if (length(resgenes) > 0){
	d2 =list(normaldata=loaded2$normdata[IN,IT3], tumordata=loaded2$tumdata[IT,IT2], 
		normalnames = loaded2$normnames[IT3], genes = loaded2$tumorgenes[IT], 
		tumornames = loaded2$tumornames[IT2])#str2double
	sprintf('analyzing...\n');
   }

   indiv=resmirna$indiv[,IN2];
   resmirna2=interesting_mirna(indiv,resmirna$indivrna);

   normalmatrice= matrix( as.double(as.matrix(d2$normaldata)), dim(as.matrix(d2$normaldata))[1], 
			dim(as.matrix(d2$normaldata))[2]);
   tumormatrice=matrix(as.double(as.matrix(d2$tumordata)), dim(as.matrix(d2$tumordata))[1], 
			dim(as.matrix(d2$tumordata))[2]);

   exprN = normalize_expr_data(tumormatrice,normalmatrice);

v=rep(0,dim(exprN)[2])
for (h in 1 : dim(exprN)[2]){
   nonnull= exprN[which(is.na(exprN[,h])==FALSE),h];
   dens=density(nonnull)
   indmode=dens$x[which(dens$y==max(dens$y)) ];
v[h]=(indmode);
}
print (mean(abs(v)))

   exprMi=d2$genes; 
   if (clean)exprMi=substring(d2$genes,5);

   confirm=rep(0,dim(resmirna$mirna)[1]);
   predicted=rep(0,dim(resmirna$mirna)[1]);
   confirmmirna=rep("", dim(resmirna$mirna)[1]);
   v=1;
   for (u in 1:dim(resmirna$mirna)[1]){
	pos=0;
	if (resmirna$mirna[u,2]<resmirna$mirna[u,3]) pos=1;   
	res=test_expression(resmirna$mirna[u,],pos,exprN,exprMi);
	if(res$mirna!=""){
	confirm[v]=res$confirmed;
	predicted[v]=res$predicted;
	confirmmirna[v]=res$mirna;
	v=v+1;
	}
   }
   confirmation=cbind(confirmmirna[1:(v-1)], confirm[1:(v-1)],predicted[1:(v-1)]);
   print(mean(confirm[1:(v-1)]));
}



#confirmation[which(confirmation[,3]>0.7),]
#remove everything close to 0  (abs<0.7)
#exprN= 1000000000*pmin(pmax(abs(exprN)-0.7,0),0.000000001)*(exprN)

#res=test_expression_indiv(resmirna2$indiv,resmirna2$indivrna,exprN[],exprMi[])

#write.table(cbind(as.matrix(prediction$mirnas),prediction$betas),"betas",col.names=FALSE, row.names=FALSE);
#write.table(cbind(exprMi,exprN),"normalized",col.names=FALSE, row.names=FALSE);
#coherence=coherence_estimation(exprN);




