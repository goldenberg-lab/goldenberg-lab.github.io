test_expression=function(mirna,pos,exprN,exprMi){

type=substring(mirna[1],1,3);
ind=substring(mirna[1],5);
maxconfirm=-1;
maxmirna="";

str=unlist(strsplit(ind, "/"));
for (i in 1:length(str)){
	cmirna=paste(type, "-",str[i], sep='');
	j= which(exprMi==cmirna);
	confirmation=0;
        if (length(j)==0){
        indnonnumeric=suppressWarnings(is.na(as.numeric(substring(exprMi,nchar(exprMi))))) ;
        j= intersect(which(substring(exprMi,1,nchar(exprMi)-1)==cmirna),indnonnumeric);
	}
	if (length(j)>0){
        for (u in 1:length(j)){
		if (pos) {confirmation=length(which(exprN[j[u],] >0))/length(exprN[j[u],]);}
		else {confirmation=length(which(exprN[j[u],] <0))/length(exprN[j[u],]);}
		print(paste(cmirna,"confirmed at",confirmation," predicted in ",mirna[4], 				mirna[5],mirna[1],mirna[2],mirna[3],"\n" ));
		if (maxconfirm<confirmation){maxconfirm=confirmation;maxmirna=cmirna;}
		#print(exprN[j[u],]);
        }
	}

}

return(list(mirna=maxmirna,confirmed=maxconfirm,predicted=mirna[4]));


}
