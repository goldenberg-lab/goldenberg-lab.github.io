nrep=10000;
samplesize=10;
v=rep(0,nrep);
for (i in 1:nrep){
select=sample(dim(exprN)[1],size=samplesize);
sum=0;
for (j in 1:samplesize){
k=runif(1,-1,1)
if (k>0) sum=sum+length(which(exprN[select[j],]>0))/length(exprN[select[j],])
if (k<0) sum=sum+length(which(exprN[select[j],]<0))/length(exprN[select[j],])
}
v[i]= sum/samplesize;
}
p=length(which(v>0.77))/length(v)

