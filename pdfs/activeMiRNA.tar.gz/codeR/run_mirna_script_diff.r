 #load directors
if (0){
for (i in 1:4){
 i
 sprintf('loading net...\n');
 net = load_mirna_net(); 
 sprintf('loading data...\n');
 d1 = load_denoised_dir_from_mat(i);
 sprintf('analyzing...\n');
 res[i] = run_mirna_one_ds(d1,net);
}
}

clean=1;
mirnadatasets = c('../../data/breast_cancer/final/breast2');#GSE22058preprocessed/mskcc 

datasets = c('GSE10810', 'GSE10927', 'GSE11024', 'GSE11151', 'GSE12368', 'GSE13601', 'GSE13911', 
	'GSE14001', 'GSE15471', 'GSE16515','GSE19826', 'GSE23878', 'GSE6631', 'GSE7904', 'GSE8607',
'GSE8671', 'GSE9348', 'GSE9844');

alldatasets = c('GSE10072', 'GSE13597', 'GSE15852', 'GSE3167', 'GSE12907', 'GSE15641', 'GSE21122', 'GSE6008', 'GSE10810', 'GSE10927', 'GSE11024', 'GSE11151', 'GSE12368', 'GSE13601', 'GSE13911', 
        'GSE14001', 'GSE15471', 'GSE16515','GSE19826', 'GSE23878', 'GSE6631', 'GSE7904', 'GSE8607',
'GSE8671', 'GSE9348', 'GSE9844');

datanames = c('Breast','Adrenocortical','Renal','Renal mixed','Adrenocortical','Tongue SSC',
'Gastric','Ovarian','Pancreatic','Pancreatic','Gastric','Colorectal','HeadNeck SSC',
'Breast','Testicular','Colorectal Ad','Colorectal','Tongue SSC');

library(R.matlab)
library(Matrix)
source("codeR/load_mirna_net.r")
source("codeR/readmatwlabels.r")
source("codeR/run_mirna_one_ds.r")
source("codeR/normalize_expr_data.r")
source("codeR/load_couple.r")
source("codeR/convertGeneDouble.r")
source("codeR/interesting_mirna.r")
source("codeR/test_expression.r")
source("codeR/test_expression_indiv.r")
source("codeR/coherence_estimation.r")

library(glmnet)

#net = load_mirna_net();
netread=read.table("newnet2",check.names=FALSE);
net=list(genes=rownames(netread), mirnas = substring(colnames(netread),5), data = as.matrix(netread));

currdir = 'data/';
ind = 1;
moreres=array(list(), length(mirnadatasets));
for (i in 1:length(mirnadatasets)){
   i
   loaded=load_couple(currdir,mirnadatasets[i],'.log2profbeta.txt','.normal.txt');
   resgenes=loaded$tumorgenes;
   if (length(resgenes) > 0){
	d1 =list(normaldata=loaded$normdata, tumordata=loaded$tumdata, 
	        normalnames = loaded$normnames, genes = loaded$tumorgenes, 
		tumornames = loaded$tumornames)#str2double
	sprintf('analyzing...\n');
	prediction = run_mirna_one_ds(d1,net);
	moreres[[ind]]=prediction;
	ind = ind+1;
  }

   resmirna=interesting_mirna(prediction$betas,prediction$mirnas);

   loaded2=load_couple(currdir,mirnadatasets[i],'.miRNA.log2profbeta.txt','.miRNA.normal.txt');
   
   if (clean){
   loaded$tumornames=substr(loaded$tumornames,1,16);
   loaded2$tumornames=substr(loaded2$tumornames,1,16);loaded2$normnames=substr(loaded2$normnames,1,16);
   }
   resIntersect = intersect(loaded2$tumorgenes,loaded2$normgenes);#str2double
   IT=as.vector(match(resIntersect,loaded2$tumorgenes));
   IN=as.vector(match(resIntersect,loaded2$normgenes));
   resIntersect = intersect(loaded2$tumornames,loaded$tumornames);#str2double
   IT2=as.vector(match(resIntersect,loaded2$tumornames));
   IN2=as.vector(match(resIntersect,loaded$tumornames));


   if (length(resgenes) > 0){
	d2 =list(normaldata=loaded2$normdata[IN,], tumordata=loaded2$tumdata[IT,IT2], 
		normalnames = loaded2$normnames, genes = loaded2$tumorgenes[IT], 
		tumornames = loaded2$tumornames[IT2])#str2double
	sprintf('analyzing...\n');
   }

   indiv=resmirna$indiv[,IN2];
   resmirna2=interesting_mirna(indiv,resmirna$indivrna);

   normalmatrice= matrix( as.double(as.matrix(d2$normaldata)), dim(as.matrix(d2$normaldata))[1], 
			dim(as.matrix(d2$normaldata))[2]);
   tumormatrice=matrix(as.double(as.matrix(d2$tumordata)), dim(as.matrix(d2$tumordata))[1], 
			dim(as.matrix(d2$tumordata))[2]);

   exprN = normalize_expr_data(tumormatrice,normalmatrice);
   exprMi=d2$genes;
   if (clean)exprMi=substring(d2$genes,5);

   confirm=rep(0,dim(resmirna$mirna)[1]);
   predicted=rep(0,dim(resmirna$mirna)[1]);
   confirmmirna=rep("",dim(resmirna$mirna)[1]);
   v=1;
   for (u in 1:dim(resmirna$mirna)[1]){
	pos=0;
	if (resmirna$mirna[u,2]<resmirna$mirna[u,3]){pos=1;}
	res=test_expression(resmirna$mirna[u,],pos,exprN,exprMi);
	if(res$mirna!=""){
	confirm[v]=res$confirmed;
	predicted[v]=res$predicted;
	confirmmirna[v]=res$mirna;
	v=v+1;
	}
   }
   confirmation=cbind(confirmmirna[1:(v-1)], confirm[1:(v-1)],predicted[1:(v-1)]);
   print(mean(confirm[1:(v-1)]));

#confirmation[which(confirmation[,3]>0.8),]
#remove everything close to 0  (abs<0.7)
#exprN= 1000000000*pmin(pmax(abs(exprN)-0.7,0),0.000000001)*(exprN)

res=test_expression_indiv(resmirna2$indiv,resmirna2$indivrna,exprN[],exprMi[])

write.table(cbind(as.matrix(prediction$mirnas),prediction$betas),"betas",col.names=FALSE, row.names=FALSE);
write.table(cbind(exprMi,exprN),"normalized",col.names=FALSE, row.names=FALSE);

coherence=coherence_estimation(exprN);
}

