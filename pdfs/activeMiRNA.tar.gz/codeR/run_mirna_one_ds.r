#res = run_mirna_one_ds('director1.mat');
run_mirna_one_ds= function(d1,net){

resIntersect = intersect(as.vector(t(net$genes)),d1$genes);#instead of d1#genes
genes=sort(resIntersect);
IN=match(genes, as.vector(t(net$genes)));#IN=resIntersect$IN;
ID=match(genes, d1$genes);#ID=resIntersect$ID;

sprintf('there are %d genes\n',length(genes));
if (length(genes) > 0){
normalmatrice= d1$normaldata;#matrix( as.double(as.matrix(d1$normaldata)), dim(as.matrix(d1$normaldata))[1], dim(as.matrix(d1$normaldata))[2]);
tumormatrice= d1$tumordata;#matrix(as.double(as.matrix(d1$tumordata)), dim(as.matrix(d1$tumordata))[1], dim(as.matrix(d1$tumordata))[2]);

if (length(normalmatrice)==0){
exprN = tumormatrice;
} else exprN = normalize_expr_data(tumormatrice,normalmatrice,1);

expr= list(data = exprN[ID,], tumor = d1$tumornames, rowlabels = d1$genes[ID]);
network = net$data[IN,];

print("details");
print(dim(expr$data))
print(dim(net$data))

resnetsize = dim(network);
resbetas = matrix(0,length(net$data[1,]),length(expr$data[1,]));
resdev=rep(NA, length(expr$data[1,]));
resdf=rep(NA, length(expr$data[1,]));

for (ii in 1:length(expr$data[1,])){
    if (1){
    CVerr = cv.glmnet(as.matrix(network),as.matrix(expr$data[,ii]),alpha=0.9,lambda=c(0.025,0.023));#,lambda=c(0.035,0.032)  0.077,0.074 c(0.027,0.025)
    } else {
    #using sparse matrix
    mat=as.matrix(network);
    CVerr = cv.glmnet(sparseMatrix(1+(which(mat==1)-1)%%dim(mat)[1],  1+(which(mat==1)-1)%/%dim(mat)[1]), as.matrix(expr$data[,ii]));
    }
    ind = which(CVerr$cvm==min(CVerr$cvm));#stderr  choose CVerr$cvm==min(CVerr$cvm)  or CVerr$lambda==CVerr$lambda.1se
    ind2=which(CVerr$lambda==CVerr$lambda.1se);
    print(paste(ind, CVerr$nzero[ind]," and ",ind2, CVerr$nzero[ind2]));#CVerr$nzero[ind]
    #if (ind<6) {
    #ind=14;print(paste(" transformed into 14 ", CVerr$nzero[ind]));
    #} else ind=ind-4;
    if (length(ind)>1) ind=ind[1];
    resbetas[,ii] = CVerr$glmnet.fit$beta[,ind];
    resdev[ii] = CVerr$glmnet.fit$dev.ratio[ind];#dev
    resdf[ii] = CVerr$glmnet.fit$df[ind];
}
    restumornames = d1$tumornames;
    resmirnas = net$mirnas;

res= list(netsize = resnetsize, betas = resbetas, dev = resdev, df = resdf, tumornames=restumornames, mirnas=resmirnas);

return (res);
}
else return (0);
}
