library(Matrix)
library(glmnet)
library(Rlab)
print("Packages loaded");

source("codeR/load_mirna_net.r")
source("codeR/readmatwlabels.r")
source("codeR/run_mirna_one_ds.r")
source("codeR/normalize_expr_data.r")
source("codeR/load_couple.r")
source("codeR/convertGeneDouble.r")
source("codeR/interesting_mirna.r")
source("codeR/test_expression.r")
source("codeR/test_expression_indiv.r")
source("codeR/simulate.r");
source("codeR/myImagePlot.r")
print("Functions loaded");

netread=read.table("newnet2",check.names=FALSE);
net=list(genes=rownames(netread), mirnas = substring(colnames(netread),5), data = as.matrix(netread));
print("Net loaded");

#load protein interaction net
protnet=matrix(0,length(net$genes), length(net$genes));
protnetfill=read.table("combined_net.txt",check.names=FALSE);
print(paste("File contains ",dim(protnetfill)[1], " entries on ",length(net$genes)," genes"));
for (i in 1:dim(protnetfill)[1]){
x1=which(net$genes==protnetfill[i,1]);
x2=which(net$genes==protnetfill[i,2]);
protnet[x1,x2]=protnetfill[i,3]
}
print("Matrix filled");
protnetsq=protnet%*%protnet;
print("Squared matrix filled");
protnetsq=protnetsq/(rowSums(protnetsq)+0.000000000000001);

print("Interactions loaded");

diffusions=c(0,0.1,0.25,0.4,0.6,0.8);#=0.1;
noisemrna=c(0,2,4,7);#=1;
multipliers=1;#=c(0,1,4,7,10);
multipliers2=0;#=c(0,1,4,7,10);
variable1=diffusions;
variable2=noisemrna;

text="mrna2";#"edges";

meansSens=matrix(0,length(variable1),length(variable2));
meansConf=matrix(0,length(variable1),length(variable2));
meansPrec=matrix(0,length(variable1),length(variable2));
sdSens=matrix(0,length(variable1),length(variable2));
sdConf=matrix(0,length(variable1),length(variable2));
sdPrec=matrix(0,length(variable1),length(variable2));

print("Starting simulations..");

for (i in 1:length(diffusions)){
for (j in 1:length(multipliers)){
for (k in 1:length(multipliers2)){
for (l in 1:length(noisemrna)){

print(paste("parameters : ",i," ",j," ",k," ",l));
sens=NULL;prec=NULL;conf=NULL;
for (z in 1:10){
res=simulate(net,protnet,protnetsq,3,diffusions[i],multipliers[j],multipliers2[k],noisemrna[l],1.5);
sens=c(sens,res$sensitivity);
prec=c(prec,res$precision);
conf=c(conf, res$confirmation);
}

i1=i;i2=l;
meansSens[i1,i2]=mean(sens);
meansConf[i1,i2]=mean(conf);
meansPrec[i1,i2]=mean(prec);
sdSens[i1,i2]=sd(sens);
sdConf[i1,i2]=sd(conf);
sdPrec[i1,i2]=sd(prec);
}
}
}
}

write(meansSens,paste(text,"SensitivityMatrix"));
write(meansPrec,paste(text,"PrecisionMatrix"));
pdf(paste(text,"Sensitivity"));
myImagePlot(meansSens);
dev.off();
pdf(paste(text,"Precision"));
myImagePlot(meansPrec);
dev.off();




