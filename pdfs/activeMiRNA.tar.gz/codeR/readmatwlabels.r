 readmatwlabels=function (filename,startind,commentchar){
# assumes first column to be row labels and first row to be column labels

if (nargs() < 3){
  commentchar = '#';
}
if (nargs() < 2){
  startind = 2;
}
  

paste(filename,"\n")

lines     = read.table(filename,comment.char=commentchar,sep='',stringsAsFactors = FALSE);
#lines  <- data.frame(lapply(lines , as.character), stringsAsFactors=FALSE);

  temp = lines[1,];
collabels = temp[startind:length(temp)];
numrows   = length(lines[,1])
numcols = length(collabels)
rowlabels= rep(0,numrows-1);


#datamat = matrix(0,numrows-1,numcols);


rowlabels=lines[2:numrows,1];
m=as.matrix(lines[2:numrows,startind:(numcols+startind-1)]);
datamat=matrix( as.double(m),dim(m)[1],dim(m)[2]);

tovisit=which(is.na(rowSums(datamat)));
for (i in tovisit){
if (is.na(datamat[i,1]))datamat[i,1]=datamat[i,2];
for (j in 2:dim(datamat)[2]){
if (is.na(datamat[i,j]))datamat[i,j]=datamat[i,j-1];
}
}

#for (ii in 2:numrows){
	#we separate out nextline and the assignment to entries, so that if the user has specifically defined tablewidth to be larger than
	#the first line for example (if the last column is an optional flag), we can still read in the rest of the lines, which will not
	#be the full width of entries
	
	#rowlabels[ii-1] = lines[ii,1];
        #may be I need to add NaNs
	#datamat[ii-1,] = t(lines[ii,startind:(numcols+startind-1) ]);
#}


return (list(genes=rowlabels,names=collabels,data=datamat))
}


