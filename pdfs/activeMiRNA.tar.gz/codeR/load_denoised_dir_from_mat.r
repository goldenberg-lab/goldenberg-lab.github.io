load_denoised_dir_from_mat= function(dirnum){

filename = paste('/home/anna/cannet/director/dir',num2str(dirnum),'profiles.denoised.mat');
denoised=readMat(filename);
d1= list(normaldata=denoised$normaldata, tumordata = denoised$data[92], genenames = denoised$genenames, genes = denoised$genes, tumornames = denoised$tumornames)
return(d1);
}
