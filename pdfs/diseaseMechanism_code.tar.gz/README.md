# diseaseMechanism
