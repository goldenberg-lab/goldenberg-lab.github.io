
top_cause_proba= function(cause,n){return(cause[which(cause[,4]==0)[1:n],2]);}
top_cause_gene= function(cause,n){return(cause[which(cause[,4]==0)[1:n],1]);}
top_cause_type= function(cause,n){return(cause[which(cause[,4]==0)[1:n],3]);}
top_cause_all= function(cause,n){return(cause[which(cause[,4]==0)[1:n],]);}

#Test other methods . Return p-values for every gene
other_methods=function(trans,labels,genesToTest,tests,perm,mf=NULL,dict=NULL, removeCommon=FALSE){
pvals=matrix(2,length(genesToTest) , length(tests));
k=1;
currentmafs=colSums(trans$mat)/(2*dim(trans$mat)[1]);
for (i in genesToTest){
cols=which(trans$gene==i);
colsrare=which(trans$gene==i & currentmafs<0.05);# real MAFs are mf[dict[trans$snps]]
if (removeCommon)cols=colsrare;
if(length(cols)>1){
  if (tests=="CAST"){ if (length(colsrare)>1){pvals[k,]=CAST(labels, trans$mat[,colsrare])$asym.pval;}
  }else if (tests=="VT"){
      pvals[k,]=VT(labels, trans$mat[,cols], perm=100)$perm.pval;
      if (!is.na(pvals[k,1]) && pvals[k,1]<0.05)pvals[k,]=VT(labels, trans$mat[,cols], perm=1000)$perm.pval;
      if (!is.na(pvals[k,1]) && pvals[k,1]<0.005)pvals[k,]=VT(labels, trans$mat[,cols], perm=10000)$perm.pval;
      if (perm>10000 && !is.na(pvals[k,1]) && pvals[k,1]<0.0005)pvals[k,]=VT(labels, trans$mat[,cols], perm=100000)$perm.pval;
      if (perm>100000 && !is.na(pvals[k,1]) && pvals[k,1]<0.00005)pvals[k,]=VT(labels, trans$mat[,cols], perm=1000000)$perm.pval;
  }else if (tests=="CALPHA"){ pvals[k,]=CALPHA(labels, trans$mat[,cols])$asym.pval;
  }else if (tests=="RWAS"){ if (length(colsrare)>1){pvals[k,]=RWAS(labels, trans$mat[,cols])$asym.pval;}
  }else if (tests=="SKAT"){pvals[k,]=SKAT(labels, trans$mat[,cols])$asym.pval;
  }else if (tests=="SKAT-O"){ x=SKAT_Null_Model(labels ~ 1,out_type="D",Adjustment=FALSE);pvals[k,]=SKAT(trans$mat[,cols],x,method="optimal.adj")$p.value;# was trans$mat[,cols] instead of 1
  }else pvals[k,]=MULTI(labels, trans$mat[,cols],tests=tests,perm = perm)$pvalue;
} else {if (length(cols)==1){if(length(unique(trans$mat[,cols]))>1){pvals[k,]=chisq.test(labels, trans$mat[,cols])$p.value;}else pvals[k,]=1.5;}}
k=k+1;
}
return(pvals)
}

performance_assessor=function(predict, truth){
sensitivity=length(which(predict %in% truth))/length(truth) #sensitivity
if (length(predict)){precision=length(which(predict %in% truth))/length(predict);} else precision=1; #precision
return(c(sensitivity, precision))
}

fmeasure=function(sens, prec){
return(2*sens*prec/(0.00000000001+sens+prec))
}

run_dmgwas=function(net1,pvals,patExpr,ctrExpr){
networkInMatForm=matrix(0,sum(unlist(lapply(net1,length))),2);
k=1;for (w in 1:length(net1)){if(length(net1[[w]])){networkInMatForm[k:(k+length(net1[[w]])-1),]=cbind(w,net1[[w]]) ;k=k+length(net1[[w]]); }}
patExprfr=NULL;ctrExprfr=NULL;
if (length(patExpr))patExprfr=data.frame(1:length(net1),patExpr);if (length(ctrExpr))ctrExprfr=data.frame(1:length(net1),ctrExpr);
dmgwas=dms(networkInMatForm,data.frame(1:length(net1),pvals),patExprfr,ctrExprfr);
topmodule=as.numeric(unlist(chooseModule(dmgwas,1,plot=FALSE)$modules));
return(list(topmodule=topmodule,dmgwas=dmgwas));
}

get_occurences=function(geneslabels,u,v){
occ=matrix(0,2,length(geneslabels)+1);colnames(occ)<- c(geneslabels,"Others");
for(i in 1:(length(geneslabels)+1)){ind=which(u==i);if(length(ind)){occ[1,i]=length(which(v[ind]=="Qual"));occ[2,i]=length(which(v[ind]=="Expr"));}}
return(occ)
}

plot_graphs= function(x,pheno,resultdir,genestodraw,suff=NULL,reorder=TRUE){
top=3;
ord=1:length(pheno);if(reorder)ord=order(pheno);
topcauseproba=matrix(as.numeric(unlist(lapply(x$causes,top_cause_proba,top))),nrow=3);
topcausegene=matrix(as.numeric(unlist(lapply(x$causes,top_cause_gene,top))),nrow=3);
tocausetype=matrix(as.character(unlist(lapply(x$causes,top_cause_type,top))),nrow=3);
#png(paste(resultdir,"resultSep",suff,".png",sep=""));plot(1:length(pheno),topcauseproba[1,ord]);dev.off();# could use rowSums over the top causes
png(paste(resultdir,"resultPred",suff,".png",sep=""));plot(ord,x$predict[ord]);u=which(pheno[ord]>0.5);points(ord[u],x$predict[ord[u]],col="red");  dev.off();
png(paste(resultdir,"resultNetcontrib",suff,".png",sep=""));hist(exp(x$munetall[,2]));dev.off();
if(length(genestodraw)){
png(paste(resultdir,"resultProba",suff,".png",sep=""));plot(1:length(genestodraw),x$h[genestodraw]);dev.off();
u=match(topcausegene[1,which(pheno==1)],genestodraw);u[is.na(u)]<- length(genestodraw)+1; 
v=tocausetype[1,which(pheno==1)];
#occ=matrix(0,2,length(genestodraw)+1);colnames(occ)<- c(as.character(genenames[genestodraw]),"Others");
#for(i in 1:length(genestodraw)){ind=which(u==i);if(length(ind)){occ[1,i]=length(which(v[ind]=="Qual"));occ[2,i]=length(which(v[ind]=="Expr"));}}
png(paste(resultdir,"resultFirstGene",suff,".png",sep=""));barplot(get_occurences(as.character(genenames[genestodraw]),u,v),las=2,ylab="Number of patients", col=c("red","blue"),cex.names=0.80,legend=c("Coding variants","Transcriptome"));dev.off();

}
}



generate_oncoprint_input= function(causes,pheno,genenames,includedpatientids,thresh){
 cases=which(pheno>0.5);
 dataframe=data.frame(stringsAsFactors=FALSE,check.names=FALSE, pat=numeric(0), gene = numeric(0), prob = numeric(0), type = character(0), id=numeric(0));
 for (i in cases){
 sel=which(causes[[i]][,2]>thresh);
 if (length(sel))dataframe=rbind(dataframe, data.frame(pat=i,causes[[i]][sel,]))
 }
 selectedgenes=unique(dataframe[,2]);
 matchgene=match(dataframe[,2],selectedgenes)

 if (length(selectedgenes)){
 mat1=matrix(0,length(selectedgenes),length(cases));rownames(mat1) <- genenames[selectedgenes];colnames(mat1) <- names(includedpatientids)[cases];
 mat2=matrix(0,length(selectedgenes),length(cases));rownames(mat2) <- genenames[selectedgenes];colnames(mat2) <- names(includedpatientids)[cases];
 snps=which( (dataframe[,4]=="Qual") & (dataframe[,5]==0) & (dataframe[,3]>thresh));
 expr=which((dataframe[,4]=="Expr") & (dataframe[,3]>thresh));
 if (length(snps))for (i in 1:length(snps))mat1[matchgene[snps[i]],dataframe[snps[i],1]]=1;
 if (length(expr))for (i in 1:length(expr))mat2[matchgene[expr[i]],dataframe[expr[i],1]]=1;
 } else {mat1=NULL; mat2=NULL;}
return(list(snv=mat1,expr=mat2));
}

generate_oncoprint_multi=function(folder, thresh=0.3){
guni=c();puni=c();  library(ComplexHeatmap);
for (i in 1:10){x=read.table(paste(folder,"results_rep",i,"_1/","causalsnv.txt",sep=""));guni=unique(c(guni,rownames(x)));puni=unique(c(puni,colnames(x)));}
matsnv=matrix(0,length(guni),length(puni));rownames(matsnv)<- guni; colnames(matsnv)<- puni;
matexpr=matrix(0,length(guni),length(puni));rownames(matexpr)<- guni; colnames(matexpr)<- puni;
matrep=matrix(0,length(guni),length(puni));
for (i in 1:10){
x=read.table(paste(folder,"results_rep",i,"_1/","causalsnv.txt",sep=""));
y=read.table(paste(folder,"results_rep",i,"_1/","causalexpr.txt",sep=""));
matrep[,which(colnames(matsnv)%in% colnames(x))]=matrep[,which(colnames(matsnv)%in% colnames(x))]+1;
matchg=match(rownames(x),guni);
matchp=match(colnames(x),puni);
matsnv[matchg,matchp]=matsnv[matchg,matchp]+as.matrix(x);
matexpr[matchg,matchp]=matexpr[matchg,matchp]+as.matrix(y);
}
matsnv=matsnv/(matrep+0.0000001);matsnv[matsnv>=thresh]<- 1; matsnv[matsnv<thresh]<- 0;
matexpr=matexpr/(matrep+0.0000001);matexpr[matexpr>=thresh]<- 1; matexpr[matexpr<thresh]<- 0;
 pdf(paste(folder,"oncoprint.pdf",sep=""));
 print(oncoPrint(list(snv=matsnv[which(rowSums(matsnv)>0),],expr=matexpr[which(rowSums(matsnv)>0),])));#WARNING print is necessary here for a weird a reason because I am inside an "if"
 dev.off();
}


pie_plot_patients=function(cause,bestgenes,genenames,resultdir,clock,ind=1){
cau=data.frame(genenames[as.numeric(cause[,1])],as.numeric(cause[,2]), cause[,3])[which(cause[,4]==0),];
indcau=which(cau[,1] %in% genenames[bestgenes]);
others=sum(cau[-indcau,2]);
labscharadd=sapply(indcau,function(x){if (as.character(cau[x,3])=="Qual")return("");return(paste("(",as.character(cau[x,3]),")",sep=""))})
labschar=sapply(indcau,function(x)paste(as.character(cau[x,1]),labscharadd[x],sep=""))
png(paste(resultdir,"resultPatient",ind,".png",sep=""));pie(c(cau[indcau,2],others),labels=c(labschar,"Others"),clockwise=clock,init.angle=0,col=rainbow(length(indcau)+1,alpha=0.3));dev.off();
}

#functions for validation
permute=function(rep, ord,f){
 real=f(ord)
 perm=rep(0,rep);
 for (i in 1:rep){
   permord=sample(ord,length(ord));
   perm[i]=f(permord);
 }
 pval=length(which(perm>=real))/rep;
 return(list(real=real,pval=pval,perm=perm))
}

psea_1d=function(pheno,pred,w=NULL,rep=5000,early=10){# pred are used as weights by default, Should be centered around 0
 if (length(w)==0){w=abs(pred);}
 if (length(w)==1)w=rep(1,length(pred));
 ord=order(pred,decreasing=FALSE)
 signmult=pheno;signmult[which(pheno==0)]=-1;
 esa0=function(s,o)earlystop(cumsum( (s*w)[o]),early); 
 esa_1d=function(s)max(esa0(s,ord)); 
 #map=mean(cumsum(as.numeric(pheno[ord]==1))/(1:length(ord)))#mean average precision
 esind=which.max(esa0(signmult,ord));
 esperm=permute(rep,signmult,esa_1d )
 return(list(es=esperm$real,pval=esperm$pval,esind=esind))
}

testhypergeom=function(pheno,expr,rep=5000){
 ord=order(expr,decreasing=FALSE);
 n=length(which(pheno>0.5));
 testhypergeom0=function(pheno,o)sapply(1:n, function(x)dhyper(sum(pheno[o[1:x]]),n,length(which(pheno<=0.5)),x))
 testhypergeom_1d=function(pheno)-min(testhypergeom0(pheno,ord));#- because permute look the upper end
 h_ind=which.min(testhypergeom0(pheno,ord));
 hyperperm=permute(rep,pheno,testhypergeom_1d)
 return(list( hypermin=-hyperperm$real,pval=hyperperm$pval, h_ind=h_ind))
}

likelihhood_comp=function(pheno,pred,rep=5000){
return(permute(rep,pheno,function(pheno)sum( pheno*log(pred) + (1-pheno)*log(1-pred) ) ) )
}


earlystop=function(x,early,replacer=0){
if (early==0)return( c( x[1:(length(x)/2)], rep(0,length(x)-(length(x)/2))   )  );
y=cummax(x);i=early;
while((i+early)<(length(x)/2) & y[i+early]>y[i])i=i+i;
x[(i+early):length(x)]=replacer;
return(x)
}




