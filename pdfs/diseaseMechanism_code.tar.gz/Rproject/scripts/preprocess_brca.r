#!/hpf/tools/centos6/R/3.2.3/bin/Rscript
if (length(commandArgs(TRUE))<3){print("Error: incorrect number of arguments");if(NA)print("Error");}
dir=commandArgs(TRUE)[1];#"/hpf/largeprojects/agoldenb/aziz/brca/processed/"
outputdir=commandArgs(TRUE)[2]; #"IntClust8-10"; #LumB-Basal"
outputind=commandArgs(TRUE)[3];
if (length(commandArgs(TRUE))>3){cases=commandArgs(TRUE)[4]} else {cases=NULL;};
if (length(commandArgs(TRUE))>4){controls=commandArgs(TRUE)[5]} else {controls=NULL;};

  #"ER-/HER2-"; "ER+/HER2- Low Prolif";"ER+/HER2- High Prolif";"HER2+";
  #Alternatively "1" to "10" , "4ER+", "4ER-"
filename="patients.txt";   #"patients.txt" or "patients_IntClust.txt"



dir.create(paste(dir,outputdir,sep=""))
pheno=read.table(paste(dir,filename,sep=""),sep="\t",stringsAsFactors =FALSE);
indcases=which(pheno[,2]==cases);
indcontrols=which(pheno[,2]==controls);
if(length(indcases)>length(indcontrols))indcases=sample(indcases,length(indcontrols))
if(length(indcontrols)>length(indcases))indcontrols=sample(indcontrols,length(indcases))

pheno2=rbind(data.frame(pat=pheno[indcases,1],label=1,stringsAsFactors =FALSE),data.frame(pat=pheno[indcontrols,1],label=0,stringsAsFactors =FALSE));
write.table( pheno2, paste(dir,outputdir,"/patients",outputind,".txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE);
