npermut=0
indpermut=0
folder="/hpf/largeprojects/agoldenb/aziz/brca/processed/"
outputdir="LumB-LumA"
for ((ss=1; ss<2; ss=ss+1))
do
/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/scripts/preprocess_brca.r "$folder" "$outputdir" "$ss" "ER+/HER2- High Prolif" "ER+/HER2- Low Prolif"
for ((complexity=1; complexity<3; complexity=complexity+1))
do
for ratioSignal in 20 40 60 80
do
name="brca_$outputdir"
qsub -l mem=63G,vmem=63G,nodes=1:ppn=1,walltime=239:50:00 -N $name"_rep$ss""_$complexity""_$ratioSignal" -v dir1="$folder""$outputdir""/",dir2="$folder""$outputdir""/results_rep$ss""_$complexity""_$ratioSignal""/",expr="../migjie_BRCA.processed.txt",gene=0,pati="patients$ss"".txt",vari="../variants.txt",geno="../genotype.txt",other=0,complexity=$complexity,ratioSignal=$ratioSignal,indpermut=$indpermut,npermut=$npermut,vali="" /hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/scripts/run_job.sh
done
done
done
