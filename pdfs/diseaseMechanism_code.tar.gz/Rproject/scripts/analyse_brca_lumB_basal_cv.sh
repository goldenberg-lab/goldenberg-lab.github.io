npermut=0
indpermut=0
folder="/hpf/largeprojects/agoldenb/aziz/brca/processed/"
outputdir="LumA-LumB"
nfold=5
for ((ss=1; ss<2; ss=ss+1))
do
/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/scripts/preprocess_brca.r "$folder" "$outputdir" "$ss" "ER+/HER2- Low Prolif" "ER+/HER2- High Prolif"
/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/scripts/cross_validation_gen.r "$folder""$outputdir""/patients$ss.txt" "$folder""$outputdir""/" "$nfold" 0 0  #header was 1 for bipolar, paired is 1 for epi4k
for ((fold=1; fold<=$nfold; fold=fold+1))
do
for ((complexity=1; complexity<3; complexity=complexity+1))
do
for ((ratioSignal=10; ratioSignal<95; ratioSignal=ratioSignal+10))
do
name="brca_$outputdir"
qsub -l mem=63G,vmem=63G,nodes=1:ppn=1,walltime=239:50:00 -N $name"_rep$ss""_$fold""_$complexity""_$ratioSignal" -v dir1="$folder""$outputdir""/",dir2="$folder""$outputdir""/results_rep$ss""_$fold""_$complexity""_$ratioSignal""/",expr="../migjie_BRCA.processed.txt",gene=0,pati="patients$ss""_training""$fold.txt",vari="../variants.txt",geno="../genotype.txt",other=0,complexity=$complexity,ratioSignal=$ratioSignal,indpermut=$indpermut,npermut=$npermut,vali="patients$ss""_validation""$fold.txt" /hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/scripts/run_job.sh
done
done
done
done
