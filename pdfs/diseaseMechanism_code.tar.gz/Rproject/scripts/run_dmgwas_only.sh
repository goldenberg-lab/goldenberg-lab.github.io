#!/bin/bash
module load R/3.2.3
/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/scripts/run_dmgwas_only.r /hpf/largeprojects/agoldenb/aziz/diseaseMechanism/simul/simulnet/simul_Epilepsy_M1.txt_0_400/rep1/data.RData
#Olga_blood_pressure_genes.txt Olga_literature_confirmed_genes_hypertension.txt schizophrenia_M1.txt schizophrenia_M2.txt ASD_ID_genes_M1.txt ASD_ID_genes_M2.txt Epilepsy_M1.txt ASD_withID_genes_M1.txt ASD_withID_genes_M2.txt line.txt Kras_Star.txt Kras_Star_NoKras.txt Clique.txt Clique_half.txt ovarian_cancer_Razi_Varadan.txt

