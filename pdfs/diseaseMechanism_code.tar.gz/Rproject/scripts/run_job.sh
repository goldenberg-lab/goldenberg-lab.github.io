#!/bin/bash
module load R/3.2.3
dir0="/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/"
dir1=${dir1}
dir2=${dir2}
expr=${expr}
gene=${gene}
pati=${pati}
vari=${vari}
geno=${geno}
other=${other}
complexity=${complexity}
ratioSignal=${ratioSignal}
indpermut=${indpermut}
npermut=${npermut}
vali=${vali}
/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/analyse_data.r $dir0 $dir1 $dir2 $expr $gene $pati $vari $geno $other $complexity $ratioSignal $indpermut $npermut $vali
