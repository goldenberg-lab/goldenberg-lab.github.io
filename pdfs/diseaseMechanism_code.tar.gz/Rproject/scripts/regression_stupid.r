
diri="/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/simul/simulnet/simul_schizophrenia_M2.txt_0_400/rep1/"
#diri="simul/simulnet/configs/simul_ovarian_cancer_Razi_Varadan.txt_0_400/rep1/"
path="/home/aziz/Desktop/aziz/diseaseMechanism/";
library(grplasso)
transfile=paste(diri,"trans_snp_matrix.txt",sep="")
pheno=read.table(paste(diri,"patients.txt",sep=""));
genes=read.table(paste(diri,"genes.txt",sep=""))[,1];
truth=read.table(paste(diri,"truth.txt",sep=""),header=TRUE);
data=read.table(transfile,header=TRUE);
index=as.numeric(sapply(colnames(data),function(x)substring(unlist(strsplit(x,"__"))[1],2)));
indic=which(duplicated(sapply(1:ncol(data),function(i)paste(index[i],paste(which(data[,i]>0),collapse="-")))));
if (length(indic)){data=data[,-indic];index=index[-indic]}


#glmmod <- glmnet(x, y=as.factor(asthma), alpha=1, family="binomial")

#heldout=sample(1:nrow(pheno),nrow(pheno)/5,)
#model=grplasso(x=cbind(as.matrix(data[-heldout,]),1),y=pheno[-heldout,2],c(index,NA), lambda=1, model = LogReg())
genebased=matrix(0,nrow(data),index[length(index)]);
for (i in 1: length(index))genebased[,index[i]]=genebased[,index[i]]+data[,i];
networkName=paste(path,"networks/iref_network",sep="")## Irefindex
source(paste(path,"Rproject/functions/load_network_functions.r",sep=""));
net=load_network_genes(networkName,as.character(genes),500)$network;
matint=matrix(0,nrow(data),sum(unlist(lapply(net,length)))/2);
k=1;indi1=rep(0,ncol(matint));indi2=rep(0,ncol(matint))
for (i in 1:length(net))for(j in net[[i]])if(j>i){matint[,k]=data[,i]*data[,j];indi1=i;indi2=j;k=k+1;}
nonzerint=which(colSums(matint)>0);
indexinter=(100000+(1:ncol(matint)))[nonzerint];

index2=c(index,indexinter);
for (l in 5:40){
model=grplasso(x=cbind(as.matrix(data),matint[,nonzerint],1),y=pheno[,2],c(index2,NA), lambda=l, model = LogReg());
u=index2[order(abs(model$coefficients[-length(model$coefficients)]),decreasing=TRUE)];
nonzer=length(which(model$coefficients[-length(model$coefficients)]>0));
modifint=which(u[1:nonzer]>100000);
for (i in modifint)if (indi1[u[i]-100000] %in% truth){u[i]=indi1[u[i]-100000];}else{ 
if (indi2[u[i]-100000] %in% truth)u[i]=indi2[u[i]-100000];}
found=sort(unique(u[1:nonzer]))
sens=length(which(found %in% truth[,1] ))/nrow(truth)
prec=length(which(found %in% truth[,1] ))/length(found)
fmeas=2*sens*prec/(0.00000000001+sens+prec)
print(paste(sens,prec,fmeas))
}

Ovarian
#Lambda: 27.5  nr.var: 51 
#[1] "0.0555555555555556 0.0833333333333333 0.0666666666618667"


#PINBPA varadan
module1 1135 around UBC all except MED22 score 38.7
module2 301 around MGA 2 genes score 12.8
module3 298 around APBA1 2 genes score 12.5
module4 160 around PLLP  0 genes score 9
~7500 genes 15; module 5 have 2 genes each out of 15
Lambda: 28  nr.var: 48 
[1] "0.0555555555555556 0.0833333333333333 0.0666666666618667"
David: nothing
gorilla nothing
g
#PINBPA Epilepsy
module1 25 around UBC 19 score 9.5
module2 25 around HSPAIL 6 genes score 7.8
module2 25 around STK3 5 genes score 7.3
~7500 genes 15; module 2, 4 and 5 have 1 gene each out of 20,2,2
Lambda: 24  nr.var: 74 
[1] "0.171428571428571 0.428571428571429 0.244897959179592"
David:
GOTERM-CC-direct synaptic vesicle 11/92 510-5:1 false
GOTERM-CC-direct synaptic vesicle docking 5/8 510-5: 2 false
GOTERM-CC-direct synaptic vesicle cycle 9/63 510-5:  1 false
GOterm-BP-direct neurotransmitter secretion 7/51 0.03 2 false
overall 12 true genes , and 3 false
Gorilla:over 50 sets had FDR<0.05

#PINBPA schizophrenia
module1 940 around GRB2 16 score 33.6
module2 430 around KIAA1429 5 genes score 15
module2 254 around CLTB 3 genes score 11.8
~7500 genes 17; module 4 has 3 gene
Lambda: 30  nr.var: 44 
[1] "0.115384615384615 0.25 0.157894736837784"
david : postsynaptic density 12/184 0.015 4 are false
gorilla : 9 sets are fdr<0.05

#PINBPA ASDwithID
module1 852 around UBC 14 score 32
module2 311 around CXXC5 0 genes score 13.1
module2 311 around FYCO1 1 genes score 13.1
~7500 genes 14; module 4 has 1 gene
Lambda: 29  nr.var: 44 
[1] "0.277777777777778 1 0.43478260869225"
david:
postsyaptic menbrane 13/211 3.5 10-3 4 false
amphetamine addiction 10/66 8.7 10-3   4 false
cocaine addiction 8/49 0.01 4 false
overall 8 false 11 true
gorilla : too many sets

#PINBPA ASD-ID
module1 745 around UBC 15 score 32
module2 490 around ITGA6 8 genes score 19.4
module2 355 around UTRN 2 genes score 14.9
7098 genes 11
Lambda: 26  nr.var: 76 
[1] "0.347826086956522 0.615384615384615 0.44444444443983"
david: goterm cc direct- cell juction: 19/459 1.3 10-3 10 false






































