rep=1
name="disMec"
n=400

#/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/simul/gene_sets/
#Olga_blood_pressure_genes.txt Olga_literature_confirmed_genes_hypertension.txt schizophrenia_M1.txt schizophrenia_M2.txt ASD_ID_genes_M1.txt ASD_ID_genes_M2.txt Epilepsy_M1.txt ASD_withID_genes_M1.txt ASD_withID_genes_M2.txt line.txt Kras_Star.txt Kras_Star_NoKras.txt Clique.txt Clique_half.txt ovarian_cancer_Razi_Varadan.txt
#smaller_line.txt smaller_star_nocenter.txt smaller_star.txt Clique_third.txt
#smaller_line2.txt line2.txt line.txt
#random.txt random2.txt random3.txt
for m in random.txt random2.txt random3.txt
do
for ((i=1; i<2; i=i+$rep ))
do
echo "/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/main_Simul_Pop\
.r /hpf/largeprojects/agoldenb/aziz/diseaseMechanism/ /hpf/largeprojects/agoldenb/aziz/diseaseMechanism/simul/gene_sets/$m 0 $n 1 $i $rep" | q\
sub -l vmem=61G,nodes=1:ppn=1,walltime=23:50:00 -N $name"_$m""_$n""_$i"
done
done

