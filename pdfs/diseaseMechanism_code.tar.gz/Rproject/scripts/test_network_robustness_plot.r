#!/hpf/tools/centos6/R/3.1.1/bin/Rscript
path="/home/aziz/Desktop/aziz/diseaseMechanism/";
library(ggplot2)
codeDir=paste(path,"Rproject/",sep="");
source(paste(codeDir,"functions/analyse_results.r",sep=""));

dir="work/simul/simulnet/simulrobust/simul_20_0_"
modnet=c(-0.5,-0.2,0.2,0.5)
nrep=10;
library(ggplot2)
nc=c(100, 200,400)
netperf=array(NA,dim=c(length(modnet),length(nc),nrep,13));
for (k in 1:nrep){
for (i in 1:length(modnet)){
for (j in 1:length(nc)){
temp=read.table(paste(dir,nc[j],"/rep",k,"/performanceprim_",modnet[i],".txt",sep=""));
netperf[i,j,k,]=t(temp)
}}}

#load("netrobust.RData")

#dmres=read.table("performance10_0_100.txt");
#toplotconflux=data.frame(netperf[1,1,,c(11,12)] , netperf[1,1,,c(6,7)],netperf[2,1,,c(6,7)], netperf[3,1,,c(6,7)],netperf[4,1,,c(6,7)])
#toplotdms=data.frame(dmres , netperf[1,,c(9,10)],netperf[2,,c(9,10)], netperf[3,,c(9,10)],netperf[4,,c(9,10)])
toplotconflux=data.frame(netperf[1,1,,c(3,4,5)],netperf[2,1,,c(3,4,5)], netperf[3,1,,c(3,4,5)],netperf[4,1,,c(3,4,5)])


methods=c("true_net","remove_50","remove_20","add_20","add_50")
 methlab=as.factor(rep(sapply(methods,function(x)rep(x,nrep)),length(nc)));
 nlab=as.factor(t(matrix(nc*2,length(nc),nrep*length(methods))));
 methlab=factor(as.character(methlab),levels=c(methods[c(2,3,1,4,5)]));#NEW 




  #d2=c( as.numeric(as.matrix(toplotconflux[,2*(1:length(methods))])), as.numeric(as.matrix(toplotdms[,2*(1:length(methods))])));

  d1=c();for (i in 1:length(nc))d1=c(d1,as.matrix(data.frame(netperf[1,i,,3],netperf[1,i,,6],netperf[2,i,,6],netperf[3,i,,6],netperf[4,i,,6])));
  #precision
  d2=c();for (i in 1:length(nc))d2=c(d2,as.matrix(data.frame(netperf[1,i,,4],netperf[1,i,,7],netperf[2,i,,7],netperf[3,i,,7],netperf[4,i,,7])));
  #F-measure
  d3=fmeasure(d1,d2)
  d4=c();for (i in 1:length(nc))d4=c(d4,as.matrix(data.frame(netperf[1,i,,5],netperf[1,i,,8],netperf[2,i,,8],netperf[3,i,,8],netperf[4,i,,8])));

 
  pdf("net_sensitivity.pdf");
  update_geom_defaults("point", list(colour = NULL));
  theme_set(theme_gray(base_size = 30));
  ggplot(data=data.frame(Sensitivity=d1,Methods=methlab,Sample_size=nlab),aes(x=Sample_size,y=Sensitivity))+ geom_boxplot(aes(fill=Methods,color=Methods),width=0.6,alpha=0.65,fatten=4)+ ylim(0,1)+ theme_bw() +theme(axis.text=element_text(size=18),axis.title=element_text(size=22,face="bold"),legend.text=element_text(size=16),legend.title=element_text(size=22))#+coord_fixed(ratio = 8)#+stat_summary(fun.y=median,geom="line",aes(group=method,color=method))# Think about coloring or removing outlier ,outlier.colour=NA removes them
  dev.off();

  pdf("net_precision.pdf");
  update_geom_defaults("point", list(colour = NULL));
  theme_set(theme_gray(base_size = 30));
  ggplot(data=data.frame(Precision=d2,Methods=methlab,Sample_size=nlab),aes(x=Sample_size,y=Precision))+ geom_boxplot(aes(fill=Methods,color=Methods),width=0.6,alpha=0.65,fatten=4)+ ylim(0,1)+ theme_bw() +theme(axis.text=element_text(size=18),axis.title=element_text(size=22,face="bold"),legend.text=element_text(size=16),legend.title=element_text(size=22))#+coord_fixed(ratio = 8)#+stat_summary(fun.y=median,geom="line",aes(group=method,color=method))# Think about coloring or removing outlier ,outlier.colour=NA removes them
  dev.off();

  pdf("net_fmeasure.pdf");
  update_geom_defaults("point", list(colour = NULL));
  theme_set(theme_gray(base_size = 30));
  ggplot(data=data.frame(F_Measure=d3,Methods=methlab,Sample_size=nlab),aes(x=Sample_size,y=F_Measure))+ geom_boxplot(aes(fill=Methods,color=Methods),width=0.6,alpha=0.65,fatten=4)+ ylim(0,1)+ theme_bw() +theme(axis.text=element_text(size=18),axis.title=element_text(size=22,face="bold"),legend.text=element_text(size=16),legend.title=element_text(size=22))#+coord_fixed(ratio = 8)#+stat_summary(fun.y=median,geom="line",aes(group=method,color=method))# Think about coloring or removing outlier ,outlier.colour=NA removes them
  dev.off();

  pdf("net_nprecision.pdf");
  update_geom_defaults("point", list(colour = NULL));
  theme_set(theme_gray(base_size = 30));
  ggplot(data=data.frame(NPrecision=d4,Methods=methlab,Sample_size=nlab),aes(x=Sample_size,y=NPrecision))+ geom_boxplot(aes(fill=Methods,color=Methods),width=0.6,alpha=0.65,fatten=4)+ ylim(0,1)+ theme_bw() +theme(axis.text=element_text(size=18),axis.title=element_text(size=22,face="bold"),legend.text=element_text(size=16),legend.title=element_text(size=22))#+coord_fixed(ratio = 8)#+stat_summary(fun.y=median,geom="line",aes(group=method,color=method))# Think about coloring or removing outlier ,outlier.colour=NA removes them
  dev.off();




select=which(methlab %in% c("true_net","remove_50","remove_20"));
select=which(methlab %in% c("true_net","add_50","add_20"))
  pdf("net_sensitivityadd.pdf");
  update_geom_defaults("point", list(colour = NULL));
  theme_set(theme_gray(base_size = 30));
  ggplot(data=data.frame(Sensitivity=d1[select],Methods=methlab[select],Sample_size=nlab[select]),aes(x=Sample_size,y=Sensitivity))+ geom_violin(aes(fill=Methods,color=Methods),width=0.6,alpha=0.65)+ theme_bw() +theme(axis.text=element_text(size=18),axis.title=element_text(size=22,face="bold"),legend.text=element_text(size=16),legend.title=element_text(size=22))+stat_summary(fun.y=median,geom="point", position=position_dodge(width=0.64),aes(group=Methods,color=Methods))#+coord_fixed(ratio = 8)#+stat_summary(fun.y=median,geom="line",aes(group=method,color=method))# Think about coloring or removing outlier ,outlier.colour=NA removes them
  dev.off();
  pdf("net_precisionadd.pdf");
  update_geom_defaults("point", list(colour = NULL));
  theme_set(theme_gray(base_size = 30));
  ggplot(data=data.frame(Precision=d2[select],Methods=methlab[select],Sample_size=nlab[select]),aes(x=Sample_size,y=Precision))+ geom_violin(aes(fill=Methods,color=Methods),width=0.6,alpha=0.65)+ theme_bw() +theme(axis.text=element_text(size=18),axis.title=element_text(size=22,face="bold"),legend.text=element_text(size=16),legend.title=element_text(size=22))+stat_summary(fun.y=median,geom="point", position=position_dodge(width=0.64),aes(group=Methods,color=Methods))#+coord_fixed(ratio = 8)#+stat_summary(fun.y=median,geom="line",aes(group=method,color=method))# Think about coloring or removing outlier ,outlier.colour=NA removes them
  dev.off();


