rep=0
i=0
complexity=3
ratioSignal=60
name="ldl_low"
output="/hpf/largeprojects/agoldenb/aziz/FHS/processed/LDL_rare2/"
echo "/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/analyse_data.r /hpf/largeprojects/agoldenb/aziz/diseaseMechanism/ $output $output/results-$complexity-$ratioSignal/ 0 0 patients1.txt variants1.txt genotype.txt 0 $complexity $ratioSignal $i $rep" | qsub -l mem=40G,vmem=40G,nodes=1:ppn=1,walltime=239:50:00 -N $name"_$complexity""_$ratioSignal"

