path="/home/aziz/Desktop/aziz/diseaseMechanism/";
folder="simul/simulnet/configs/"
output="cyto/"
truthFile="random.txt"
#Olga_blood_pressure_genes.txt Olga_literature_confirmed_genes_hypertension.txt schizophrenia_M1.txt schizophrenia_M2.txt ASD_ID_genes_M1.txt ASD_ID_genes_M2.txt Epilepsy_M1.txt ASD_withID_genes_M1.txt ASD_withID_genes_M2.txt  Kras_Star.txt Kras_Star_NoKras.txt Clique.txt Clique_half.txt ovarian_cancer_Razi_Varadan.txt
#smaller_line.txt smaller_star_nocenter.txt smaller_star.txt Clique_third.txt
codeDir=paste(path,"Rproject/",sep="");

networkName=paste(path,"networks/iref_network",sep="")## Biogrid updated
n=400;
thresh=0.05;
inputdir=paste(path,folder,"simul_",truthFile,"_0_",n,"/rep1/",sep="");
outdir=paste(inputdir,output,sep="");dir.create(outdir)

truth=read.table(paste(inputdir,"truth.txt",sep=""),header=TRUE, stringsAsFactors=FALSE)[,2];
tableconflux=read.table(paste(inputdir,"mymethod.txt",sep=""), stringsAsFactors=FALSE)
tablehotnet=read.table(paste(inputdir,"hotnetbest.txt",sep=""), stringsAsFactors=FALSE)

genenames=tableconflux[,1]
genesconsidered=sort(unique(c(  truth,tableconflux[which(tableconflux[,2]>thresh),1] , tablehotnet[which(tablehotnet[,2]==1),1]  )));
source(paste(codeDir,"functions/load_network_functions.r",sep=""));
net=load_network_genes(networkName,genenames,100)$network;
firstneighbours=unlist(net[which(genenames %in% genesconsidered)]);
multipletimes=genenames[as.numeric(names(which(table(firstneighbours)>1)))];#multipletimes=c()
net2=load_network_genes(networkName,unique(sort(c(genesconsidered,multipletimes))),100);

colorhotnet=tablehotnet[match(net2$genes,tablehotnet[,1]),2]
colorconflux=tableconflux[match(net2$genes,tableconflux[,1]),2]
colorhotnetname=rep("",length(colorhotnet));colorhotnetname[which(colorhotnet==1)]="cyan";
colorconfluxname=rep("",length(colorconflux));colorconfluxname[which(colorconflux>=0.2)]="red";colorconfluxname[which(colorconflux>=0.05 & colorconflux<0.2)]="pink";
colorboth=rep("white",length(colorconflux));colorboth[which(colorhotnet==1)]="cyan";colorboth[which(colorconflux>=0.2)]="red";colorboth[which(colorconflux>=0.05 & colorconflux<0.2)]="pink";
colorboth[which(colorhotnet==1 & colorconflux>=0.2)]="purple";colorboth[which(colorhotnet==1 & colorconflux>=0.05 & colorconflux<0.2)]="plum"; 


write.table(data.frame(gene=net2$genes, size=as.numeric(net2$genes%in%  genesconsidered), border=as.numeric(net2$genes%in%  truth) , colorhotnet=colorhotnet, colorconflux=colorconflux,colorboth=colorboth), paste(outdir,"nodes_attrb_cyto.txt",sep=""),sep="\t",row.names=FALSE,quote=FALSE);#sizes

tab=networkAsTable(net2);
indabsent=which(!(genesconsidered %in% unique(sort(c(as.character(tab[,1]),as.character(tab[,3]))))))

if (length(indabsent)) {print("############HAVE TO DO AGAIN ####################################################"); tab=rbind(tab,data.frame(interactorA=genesconsidered[indabsent],type="",interactorB=""));}
write.table(tab,paste(outdir,"net_cyto.txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE);


#smaller_line 200   smaller_line2 200   line 400  line2 200   line 200  

