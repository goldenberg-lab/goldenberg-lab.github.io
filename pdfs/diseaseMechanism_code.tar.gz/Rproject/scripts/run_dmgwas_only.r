#!/hpf/tools/centos6/R/3.2.3/bin/Rscript
dirload=commandArgs(TRUE)[1];
#dirload="/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/simul/simulnet/simul_line2.txt_0_400/rep1/data.RData";
load(dirload)

if(length(methods)){
library(AssotesteR)
library(SKAT)
genesToTest=unique(trans$gene);
labels=c( rep(1,length(indPatients)),rep(0,length(indControls)));
for (w in 1: length(methods)){
pvals=other_methods(trans,labels,genesToTest,methods[w],1000000,mf,dict,removeCommon=removeCommon);
y=colSums(trans$mat); sumg=rep(0,length(genesToTest));k=1;sumg[k]=y[1];for (i in 2:length(y)){if (trans$gene[i]!=trans$gene[i-1])k=k+1;sumg[k]=sumg[k]+y[i];}
ind1=which(sumg<5 | pvals==1);
#qvals=rep(1,length(genes));qvals[genesToTest][-ind1]=twilight(pvals[-ind1])$result$qvalue # local FDR using the twilight package
#qvals=rep(1,length(genes));qvals[genesToTest][-ind1]=p.adjust(pvals[-ind1],method="fdr")   #Take qvalues from p.adjust (stats package)
#library(qvalue);qvals=rep(1,length(genes));qvals[genesToTest][-ind1]=qvalue(pvals[-ind1])$qvalues  #Take qvalues from qvalue package
inflex=meancgenes/nbgenes; #Alternative to using the inflexion point of iFDR curves (some of them have none and some are all under 0.05)
indnonzero=which(pvals<inflex);if (length(indnonzero)<20)indnonzero=which(rank(pvals)<21)
qvals=rep(1,length(genes)); qvals[genesToTest[indnonzero]]=pvals[indnonzero]  # just taking the pvalues, while making all >0.2 into zeros (epsilons)
pvals2=rep(1,length(genes)); pvals2[genesToTest]=pvals; ordpvals2=order(pvals2);#All SKAT-O results
write.table(data.frame(genes[ordpvals2],pvals2[ordpvals2]),paste(dirrep,methods[w],"0.txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE)
write.table(data.frame(genes,-log(qvals)),paste(dirrep,methods[w],".txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE)
genesToTest1=genesToTest[which(apply(pvals,1,min)<0.05/nbgenes)];#8.10e-6 is the significance threshold after multiple hypothesis
indmeasure=2*(1+length(thresh))*testVariations+3*(w-1)+1; #index where we are storing the first measurement (sensitivity)
powermeasures[z,indmeasure:(indmeasure+1)]=performance_assessor(genesToTest1,truth);#Sensitivity and Precision
powermeasures[z,indmeasure+2]=length(which(genesToTest[order(pvals)[1:length(truth)]] %in% truth))/length(truth) #precision at rank
}
print("Gene based tests performance assessment: done");
}

testdmgwas=1;
if (testdmgwas){#dmGWAS (done on SKAT pvalues)
library(dmGWAS)
skatpvals=rep(0.5,nbgenes);skatpvals[genesToTest]=pvals;
skatpvals[which(skatpvals<=10^(-16))]=10^(-16);skatpvals[which(skatpvals>=1)]=0.5#+runif(length(which(skatpvals>=1)))/2;
d1=data.frame(gene=genenames,weight=skatpvals,stringsAsFactors =FALSE);
netmat=data.frame(interactorA=rep("gene",100000),interactorB=rep("gene",100000),stringsAsFactors =FALSE)
k=1;for (i in 1:nbgenes)if(length(net1[[i]])){for(j in net1[[i]]){if (j >i){netmat[k,1]=genenames[i];netmat[k,2]=genenames[j];k=k+1;}}}
netmat=netmat[1:(k-1),]
#resdmgwas2=run_dmgwas(net1,skatpvals,expr[,affectedexpr],expr[,-affectedexpr]);
#sel=chooseModule(resdmgwas,top=0.01,plot=FALSE)
resdmgwas=dms(netmat,d1,expr1=NULL,expr2=NULL,d=1,r=0.1)
sel=resdmgwas$genesets.clear[[as.numeric(rownames(resdmgwas$zi.ordered)[1])]]
indmeasure=2*(1+length(thresh))*testVariations+3*(length(methods)+testExpr)+1;
powermeasures[z,indmeasure:(indmeasure+1)]=performance_assessor(match(sel,genenames),truth); #sensitivity and precision (#Careful result of match if sel empty or NA) 
write.table(data.frame(genenames,as.numeric(genenames %in% sel)),paste(dirrep,"dmgwas.txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE);
print("NAA method performance assessment: done");
}

write.table(powermeasures,paste(dir,"secondperformance",outputdirSuffix,"_",indrep,".txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE);
save.image(paste(dirrep,"data2.RData",sep=""))
