#This code suppose a balanced set of cases/controls with 0/1 assignments
#file="/hpf/largeprojects/agoldenb/aziz/bipolar/4-Bipolar_exomes_training.txt"
#output="/hpf/largeprojects/agoldenb/aziz/bipolar/processed/"
#file="/hpf/largeprojects/agoldenb/aziz/epi4k/patients.txt"
#output="/hpf/largeprojects/agoldenb/aziz/epi4k/"
file="/hpf/largeprojects/agoldenb/aziz/FHS/processed/LDL_High/patients1.txt"
output="/hpf/largeprojects/agoldenb/aziz/FHS/processed/LDL_High/"
#file="/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/simul/simul_10_0_200/rep1/patients.txt"
#output="/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/simul/simul_10_0_200/rep1/"
#file="/hpf/largeprojects/agoldenb/aziz/brca/processed/LumB-Basal/patients_LumB-Basal.txt"
#output="/hpf/largeprojects/agoldenb/aziz/brca/processed/LumB-Basal/"

nfold=5
/hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/scripts/cross_validation_gen.r "$file" "$output" "$nfold" 0 0  #header was 1 for bipolar, paired is 1 for epi4k
name="LDL_High"
npermut=0
indpermut=0
for ((fold=1; fold<=$nfold; fold=fold+1))
do
for ((complexity=1; complexity<5; complexity=complexity+1))
do
for ((ratioSignal=10; ratioSignal<95; ratioSignal=ratioSignal+10))
do
qsub -l mem=40G,vmem=40G,nodes=1:ppn=1,walltime=239:50:00 -N $name"_$fold""_$complexity""_$ratioSignal" -v dir1="$output",dir2="$output/results_$fold-$complexity-$ratioSignal/",expr=0,gene=0,pati="patients_training$fold.txt",vari="variants1.txt",geno="genotype.txt",other=0,complexity=$complexity,ratioSignal=$ratioSignal,indpermut=$indpermut,npermut=$npermut,vali="patients_validation$fold.txt" /hpf/largeprojects/agoldenb/aziz/diseaseMechanism/Rproject/scripts/run_job.sh
done
done
done

