#!/hpf/tools/centos6/R/3.2.3/bin/Rscript
path=commandArgs(TRUE)[1];
nb_genes_causal_str=commandArgs(TRUE)[2];
ratioExprSnp=as.numeric(commandArgs(TRUE)[3]);
sample_size=as.numeric(commandArgs(TRUE)[4]);
cores=as.numeric(commandArgs(TRUE)[5]);
indrep=as.numeric(commandArgs(TRUE)[6]);
nbrep=as.numeric(commandArgs(TRUE)[7]);
if (length(commandArgs(TRUE))>7){usenet=as.numeric(commandArgs(TRUE)[8]);} else {usenet=2;}#0 no network, 1 Direct net, 2 second order neighbours, A real number<1  influence matrix delta
useexpr=0;useharm=0; #if 0 uniform prior is used for harmfulness (0.5), expr is not used (NULL)
#For running hotnet
dirhotnet="/hpf/largeprojects/agoldenb/aziz/hotnet2-1.0.1/"; system("module load python/2.7.6-UCS4");dirpython="/hpf/tools/centos6/python/2.7.6-UCS4/bin/";

freeMem=FALSE;

local=FALSE;

if(local){
nb_genes_causal_str="12";# Can be a number (random disease module of that size), or the name of the file containing a list of genes.
sample_size=120;
ratioExprSnp=0;#c(0,0.66,1,1.5,4) for 100%, 60%,50%,40%,20% snps
path="/home/aziz/Desktop/aziz/diseaseMechanism/";
#path="/project/lipidext/diseaseMechanism/";
cores=1;freeMem=TRUE;nbrep=1;indrep=1;
usenet=2; useexpr=0;useharm=0;
dirhotnet="/home/aziz/Downloads/networks_paper/hotnet2-1.0.1/"; dirpython=""
}
outputdirSuffix=paste(basename(nb_genes_causal_str),"_",ratioExprSnp,"_",sample_size,sep="");
dir=paste(path,"simul/simul_",outputdirSuffix,"/",sep="");#output directory for the simulations
dir.create(dir);
codeDir=paste(path,"Rproject/",sep="");


#simul param
simgenelengths=FALSE;
simmaxmut=10;#max mutation per patients (kill all individuals above)
nbPatients=3000;
ratioSignalSim=1;
maxConnections=100;maxConnections2=50;#biggest hub considered; if degree higher than maxConnections2 we do not take second order neighbours
maxneighborhoodsize=300;#max second order neighberhood for selecting model
#Analysis param

npermut=0;
ratioSignal=ratioSignalSim;
complexityDistr=c(0,1,0);
decay=c(0.05,0.1,0.2,0.4);
removeCommon=FALSE;
alpha=0.5;if(sample_size>=500)alpha=0.35;
removeExpressionOnly=FALSE;
netparam=0.9; #parameter by default in the MRF
netmax=0.025;#max proba that can be originating from network (modulate strength of gene network messages)
netmaxNoise=0.15;#Correct for high degree nodes where accumulation of small signals explodes; Need to be at least 4*netmax
netrelaxed=0; #maximal net contribution computed on the basis that 1/1+x of the true genes are in the neighbourhood (this means stronger net signals in general)
propagate=FALSE;
methods=c("CAST","SKAT-O");#c("CAST","CALPHA","VT","SKAT-O");
testExpr=0;testdmgwas=0;testhotnet=1; #0 if not doing diff. expr , one if we do. Same for doing or not doing dmGWAS.
testVariations=1;#=5; #try without net, without expression or without harmfulness (add harm first, then add net or add expr)
testrobust=0; #0 nothing, 1 network/harm/expr, 2 meancgenes, 3 ratioSignal, 4 complexitydistr/decay 5 net/net1/no net
thresh=c(0.5,0.2,0.1,0.05);
exprName=paste(path,"simul_data/healthyExpr65834.txt",sep="");
#networkName=paste(path,"networks/BIOGRID3.2.98.tab2/interactions.txt",sep="");
#networkName=paste(path,"networks/HPRD_Release9_062910/interactions.txt",sep="");## HPRD network
#networkName=paste(path,"networks/BIOGRID3.4-132/Biogrid-Human-34-132.txt",sep="")## Biogrid updated
#networkName=paste(path,"networks/humannet/interactions150.txt",sep="");## HumanNet
networkName=paste(path,"networks/iref_network",sep="")## Biogrid updated
influenceMatName=paste(dirhotnet,"influence_matrices/irefindex/iref_ppr_0.45.h5",sep="");genesmapping=paste(dirhotnet,"influence_matrices/irefindex/iref_index_genes",sep="");

library(preprocessCore);
library(Matrix)
#library(modeest)#For mode computations
#library(pROC)#for ROC curve and AUC measurement
#library(robustbase) #for Sn and Qn
#library(asbio)#for biweght midvariance
source(paste(codeDir,"functions/harmonize_expr.r",sep=""));
source(paste(codeDir,"functions/simul_polyphen.r",sep=""));
source(paste(codeDir,"functions/simul_functions.r",sep=""));
source(paste(codeDir,"functions/load_network_functions.r",sep=""));
source(paste(codeDir,"functions/analyse_results.r",sep=""));


net=load_network_genes(networkName,NULL,maxConnections);
healthy_expr=as.matrix(read.table(exprName));
genes=intersect(net$genes, rownames(healthy_expr));
genesToExpr=match(genes,rownames(healthy_expr));
healthy_expr=healthy_expr[genesToExpr,];
nbgenes=length(genes);

#load SNPs
allmap=read.table(paste(path,"simul_data/outvar.var",sep=""),colClasses=rep("numeric",4))
sdamage=0.001;#threshold for harmfulness
#Simulate polyphen scores
polyph_distr=read.table(paste(path,"simul_data/polyphen.txt",sep=""));
distr1=polyph_distr[which(!is.na(polyph_distr[,2]) & polyph_distr[,1]=="deleterious"),2];
distr2=polyph_distr[which(!is.na(polyph_distr[,2]) & polyph_distr[,1]=="neutral"),2];
ps=apply(cbind(allmap[,3]>sdamage,allmap[,3]),1,simul_polyphen2,distr1=distr1,distr2=distr2);
mf=allmap[,2];#MAF

fc <- file(paste(path,"simul_data/outpat.pat",sep=""))
allmut <- lapply(strsplit(readLines(fc), "\t"), as.numeric)
close(fc)
dict=match(1:(max(allmap[,1])+1), allmap[,1]); #require allmap sorted # Avoid using many "which" later;  codelength=max(allmap[,1])+1;
nbDamage=unlist(lapply(allmut,simul_nbDamage,sdamage, allmap, dict))
allmutAvgLength= mean(nbDamage)
allmutSdLength= sd(nbDamage)


#source("functions/setexpressionratio.r");

#Simulate expression perturbations
corrector=0.9#unbiasRatio(nb_genes_causal_str);#ratio is 1 if model size 5; 0.5 md10; 3.5 md2; For 66% 1.3 md2/5
nbExprAvg=corrector*ratioExprSnp*allmutAvgLength;nbExprSd=corrector*ratioExprSnp*allmutSdLength
nbindiv=length(allmut)
allexp <-list();length(allexp) <-nbindiv;
allexpMagnitude <- list();length(allexpMagnitude) <-nbindiv;
genesID=1:nbgenes
allexp <-lapply(allexp,simul_sample,genesID,nbExprAvg,nbExprSd)
start=0.5;end=0.8;coef=6; # perturbation is unif(start,end)*coef*sd *sign
allexpMagnitude <- lapply(allexp,simul_unif,start=start,end=end)


#reapeat experiment nbtry times with the same model
powermeasures=matrix(0,nbrep,2*(1+length(thresh))*testVariations+ 3*(testExpr+length(methods))+2* testdmgwas+4*testhotnet); #measure sensitivity and precision for this method + others
contributions=matrix(0,2,nbrep);
xres=list();length(xres) <- testVariations;
for (z in 1:nbrep){
dirrep=paste(dir,"rep",indrep+z-1,"/",sep='');dir.create(dirrep);
source(paste(codeDir,"main_Simul_Disease.r",sep=""))
print("Gene contributions");
print(rowSums(indivScores_Qual));print(rowSums(indivScores_Quant));
object.size(x=lapply(ls(), get));print(object.size(x=lapply(ls(), get)), units="Mb")
source(paste(codeDir,"main_Simul_Analyze.r",sep=""))#Once this code is called I can use genenames instead of genes


for (w in 1:testVariations){
 indmeasure=2*(1+length(thresh))*(w-1)+1;#index where we are storing the first measurement (status)
 powermeasures[z,indmeasure]=xres[[w]]$status;#convergence status
 for (w1 in 1:length(thresh)){
   found=which(xres[[w]]$h>thresh[w1]);
   powermeasures[z,(indmeasure+2*w1-1):(indmeasure+2*w1)]=performance_assessor(found,truth);#Sensitivity and Precision
 }
 to=which(order(xres[[w]]$h,decreasing=TRUE) %in% truth);
 powermeasures[z,indmeasure+2*(1+length(thresh))-1]=length(which(to<= length(truth)))/length(truth);#precision at rank
 write.table( data.frame(genenames,xres[[w]]$h),paste(dirrep,"mymethod.txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE);
}
print("Method performance assessment: done");

save.image(paste(dirrep,"data.RData",sep=""))


if(length(methods)){
library(AssotesteR)
library(SKAT)
genesToTest=unique(trans$gene);
labels=c( rep(1,length(indPatients)),rep(0,length(indControls)));
for (w in 1: length(methods)){
pvals=other_methods(trans,labels,genesToTest,methods[w],1000000,mf,dict,removeCommon=removeCommon);
y=colSums(trans$mat); sumg=rep(0,length(genesToTest));k=1;sumg[k]=y[1];for (i in 2:length(y)){if (trans$gene[i]!=trans$gene[i-1])k=k+1;sumg[k]=sumg[k]+y[i];}
ind1=which(sumg<5 | pvals==1);
#qvals=rep(1,length(genes));qvals[genesToTest][-ind1]=twilight(pvals[-ind1])$result$qvalue # local FDR using the twilight package
#qvals=rep(1,length(genes));qvals[genesToTest][-ind1]=p.adjust(pvals[-ind1],method="fdr")   #Take qvalues from p.adjust (stats package)
#library(qvalue);qvals=rep(1,length(genes));qvals[genesToTest][-ind1]=qvalue(pvals[-ind1])$qvalues  #Take qvalues from qvalue package
inflex=meancgenes/nbgenes; #Alternative to using the inflexion point of iFDR curves (some of them have none and some are all under 0.05)
indnonzero=which(pvals<inflex);if (length(indnonzero)<20)indnonzero=which(rank(pvals)<21)
qvals=rep(1,length(genes)); qvals[genesToTest[indnonzero]]=pvals[indnonzero]  # just taking the pvalues, while making all >0.2 into zeros (epsilons)
pvals2=rep(1,length(genes)); pvals2[genesToTest]=pvals; ordpvals2=order(pvals2);#All SKAT-O results
write.table(data.frame(genes[ordpvals2],pvals2[ordpvals2]),paste(dirrep,methods[w],"0.txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE)
write.table(data.frame(genes,-log(qvals)),paste(dirrep,methods[w],".txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE)
genesToTest1=genesToTest[which(apply(pvals,1,min)<0.05/nbgenes)];#8.10e-6 is the significance threshold after multiple hypothesis
indmeasure=2*(1+length(thresh))*testVariations+3*(w-1)+1; #index where we are storing the first measurement (sensitivity)
powermeasures[z,indmeasure:(indmeasure+1)]=performance_assessor(genesToTest1,truth);#Sensitivity and Precision
powermeasures[z,indmeasure+2]=length(which(genesToTest[order(pvals)[1:length(truth)]] %in% truth))/length(truth) #precision at rank
}
print("Gene based tests performance assessment: done");
}

save.image(paste(dirrep,"data.RData",sep=""))

if (testExpr){#Differential expression
pvalsexp=sapply(1:nbgenes,function(x)t.test(expr[,affectedexpr], expr[,-affectedexpr])$p.value)
genesig=which(pvalsexp<0.05/nbgenes);
indmeasure=2*(1+length(thresh))*testVariations+3*length(methods)+1;
powermeasures[z,indmeasure:(indmeasure+1)]=performance_assessor(genesig,truth);
powermeasures[z,indmeasure+2]=length(which(order(pvalsexp)[1:length(truth)] %in% truth))/length(truth) #precision at rank
print("Differential expression performance assessment: done");
}

if (testdmgwas){#dmGWAS (done on SKAT pvalues)
library(dmGWAS)
skatpvals=rep(0.5,nbgenes);skatpvals[genesToTest]=pvals;
skatpvals[which(skatpvals<=10^(-16))]=10^(-16);skatpvals[which(skatpvals>=1)]=0.5#+runif(length(which(skatpvals>=1)))/2;
d1=data.frame(gene=genenames,weight=skatpvals,stringsAsFactors =FALSE);
netmat=data.frame(interactorA=rep("gene",100000),interactorB=rep("gene",100000),stringsAsFactors =FALSE)
k=1;for (i in 1:nbgenes)if(length(net1[[i]])){for(j in net1[[i]]){if (j >i){netmat[k,1]=genenames[i];netmat[k,2]=genenames[j];k=k+1;}}}
netmat=netmat[1:(k-1),]
#resdmgwas2=run_dmgwas(net1,skatpvals,expr[,affectedexpr],expr[,-affectedexpr]);
#sel=chooseModule(resdmgwas,top=0.01,plot=FALSE)
resdmgwas=dms(netmat,d1,expr1=NULL,expr2=NULL,d=1,r=0.1)
sel=resdmgwas$genesets.clear[[as.numeric(rownames(resdmgwas$zi.ordered)[1])]]
indmeasure=2*(1+length(thresh))*testVariations+3*(length(methods)+testExpr)+1;
powermeasures[z,indmeasure:(indmeasure+1)]=performance_assessor(match(sel,genenames),truth); #sensitivity and precision (#Careful result of match if sel empty or NA) 
write.table(data.frame(genenames,as.numeric(genenames %in% sel)),paste(dirrep,"dmgwas.txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE);
print("NAA method performance assessment: done");
}

save.image(paste(dirrep,"data.RData",sep=""))

if (testhotnet){
 w=length(methods)#SKAT-O or the last gene-based test is always used as input

 system(paste(dirpython,"python ",dirhotnet,"runHotNet2.py -mf ",influenceMatName," -if ",genesmapping," -hf ",dirrep,methods[w],".txt -pnp ",dirhotnet,"influence_matrices/irefindex/permuted/##NUM##/iref_ppr_0.45.h5 -o ",dirrep,sep=""))
 hotnetres=list.files(path=dirrep,pattern=".*components.txt",full.names=TRUE,recursive=TRUE);
 bestfmeas=0;bestsens=0;bestprec=0;bestcomponent="";bestfmeasall=0;bestsensall=0;bestprecall=0;bestall="";deltabest=1;deltabestall=1;
 for (i in 1:length(hotnetres)){
  #read components and transform them in sensitivity, precision
  comps=strsplit(readLines(hotnetres[i]), "\t");
  if (length(comps)){
    perfhotnetall=performance_assessor(match(unlist(comps),genenames),truth);
    fmeasall=fmeasure(perfhotnetall[1],perfhotnetall[2]);
    perfhotnet=mapply(function(x,truth)performance_assessor(match(unlist(x),genenames),truth), comps,MoreArgs=list(truth=truth)); 
    fmeas=fmeasure(perfhotnet[1,],perfhotnet[2,]);
    bestcomponentind=which.max(fmeas);
    if (fmeas[bestcomponentind]>bestfmeas){bestfmeas=fmeas[bestcomponentind];bestsens=perfhotnet[1,bestcomponentind];bestprec=perfhotnet[2,bestcomponentind];bestcomponent=paste(comps[[bestcomponentind]]); deltabest=i;}
    if (fmeasall>bestfmeasall){bestfmeasall=fmeasall;bestsensall=perfhotnetall[1];bestprecall=perfhotnetall[2];bestall=paste(unlist(comps));deltabestall=i;}
  }
 }
 indmeasure=2*(1+length(thresh))*testVariations+3*(length(methods)+testExpr)+2*testdmgwas+1;
 powermeasures[z,indmeasure:(indmeasure+1)]=c(bestsens,bestprec);
 powermeasures[z,(indmeasure+2):(indmeasure+3)]=c(bestsensall,bestprecall);#for the best concatenation of significant components (one choice of delta)
 bestallvector=unlist(strsplit(bestall," "));
 write.table(data.frame(genenames,as.numeric(genenames %in% bestallvector)),paste(dirrep,"hotnetbest.txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE,quote=FALSE);
}

}
#end repetitions

write.table(powermeasures,paste(dir,"performance",outputdirSuffix,"_",indrep,".txt",sep=""),sep="\t",row.names=FALSE,col.names=FALSE);

if(0){
  print(paste("***Stats:", mean(powermeasures[,1]),mean(powermeasures[,2])  ));
  allresults[[z1]]<- powermeasures;
  if (nbrep>1){
    perc=colSums(contributions); contributionsPercentage=100*contributions/rbind(perc,perc)
    print(paste("contribution averages: ", rowMeans(contributionsPercentage)));
  }
  source("functions/simul_plot.r")
  #results_form=simul_format_results(allresults,param1,param2)
  #simul_box(results_form,param1,param2,"")
  simul_mean_plot(allresults, methods,param1,param2,param3,"")
}

